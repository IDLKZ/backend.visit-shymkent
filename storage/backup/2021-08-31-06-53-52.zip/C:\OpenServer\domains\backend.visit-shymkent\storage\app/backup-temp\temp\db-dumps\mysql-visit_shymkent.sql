
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blogs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tag_id` bigint unsigned NOT NULL,
  `author_id` bigint unsigned NOT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_ru` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_kz` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blogs_tag_id_foreign` (`tag_id`),
  KEY `blogs_author_id_foreign` (`author_id`),
  CONSTRAINT `blogs_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `blogs_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` VALUES (2,3,1,'В Шымкенте состоится первый глэмпинг фестиваль U:ДАЧА','The first glamping festival U:DACHA will be held in Shymkent','Шымкентте алғашқы глэмпинг фестивалі өтеді U: саяжай','<p>Что такое глэмпинг? <strong>Глэмпинг </strong>&mdash; производная от слов гламур и кемпинг. Иными словами, отель в палатке.&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Такой вид отдыха создан для тех, кого вводит в стресс рюкзак за плечами и суровые горные условия. Единственное условие для глэмпинга &mdash; отель в палатке должен быть мобильным и органично вписываться в окружающую среду, не нанося ей ущерба. Почему это нужно Казахстану? Мы бы хотели избавиться от термина &laquo;маёвка&raquo;, так как оно уже изжило себя. На самом то деле, это слово обозначало нелегальное собрание рабочего класса. А во времена СССР оно уже трансформировалось, в понятие отдыха на природе, без какой-либо подготовки и комфорта. Сегодня человек настолько привязан к городской экосистеме, что ему необходимо выходить на природу время от времени. Решением этой проблемы может стать глэмпинг &mdash; новое понятие, которое подразумевает комфортный и гламурный отдых, органично вписывающийся в окружающую среду не нанося ей никакого вреда. Из-за пандемии коронавируса культурные мероприятия были отменены или перенесены. Для жителей Шымкента глэмпинг &mdash; одна из немногих возможностей посетить мероприятие на открытом воздухе. Новый формат отдыха на природе поможет развитию внутреннего туризма и познакомит людей с красотами Туркестанской области. Привлекая к новому формату традиционные образцы культуры, например, юрты, организаторы хотят объединить традиции прошлого и комфорт настоящего. Что будет на глэмпинг-фестивале U:ДАЧА? Трансфер из Шымкента в зону отдыха в селе Каскасу; Просмотр фильма на проекторе под открытом небом; Трехразовое питание + костер с маршмеллоу и жареными сосисками; Игры в волейбол, арқан тартыс и алтыбақан; Утренняя йога; Купание в речке и бане; Фотозона для атмосферных снимков; Ночлег в палатке, юрте или отдельном домике; Музыкальный квартирник. Кто будет на глэмпинг-фестивале U:ДАЧА? На музыкальном квартирнике будут выступать Мирас Жугунусов, музыканты лейбла ozenxo &mdash; @dudeontheguitar и @sulikomusic. Ведущим мероприятия станет Жансерик Кадырбаев (@kadyrbayev_). Что взять с собой на глэмпинг-фестиваль U:ДАЧА? Теплую одежду; Плед; Свою кружку; Фотоаппарат; Хорошее настроение; Удостоверение личности. Источник https://the-steppe.com/gorod/v-shymkente-sostoitsya-pervyy-glemping-festival-u-dacha</p>','<p>What is glamping? Glamping is a derivative of the words glamour and camping. In other words, the hotel is in a tent.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>This type of recreation is created for those who are stressed by a backpack on their shoulders and harsh mountain conditions. The only condition for glamping is that the hotel in the tent must be mobile and organically fit into the environment without causing damage to it. Why does Kazakhstan need this? We would like to get rid of the term &quot;Mayevka&quot;, since it has already outlived its usefulness. In fact, this word meant an illegal meeting of the working class. And during the Soviet era, it was already transformed into the concept of outdoor recreation, without any preparation and comfort. Today, people are so attached to the urban ecosystem that they need to go out into nature from time to time. The solution to this problem can be glamping &mdash; a new concept that implies a comfortable and glamorous vacation, organically fitting into the environment without causing any harm to it. Due to the coronavirus pandemic, cultural events were canceled or postponed. For residents of Shymkent, glamping is one of the few opportunities to attend an outdoor event. The new format of outdoor recreation will help the development of domestic tourism and introduce people to the beauties of the Turkestan region. By attracting traditional cultural samples to the new format, for example, yurts, the organizers want to combine the traditions of the past and the comfort of the present. What will happen at the glamping festival U: DACHA? Transfer from Shymkent to the recreation area in the village of Kaskasu; Watching a movie on a projector in the open air; Three meals a day + a bonfire with marshmallows and fried sausages; Volleyball games, arkan tartys and altybakan; Morning yoga; Swimming in the river and bath; Photo zone for atmospheric shots; Overnight in a tent, yurt or a separate house; Musical apartment. Who will be at the glamping festival U: DACHA? Miras Zhugunusov, musicians of the ozenxo label &mdash; @dudeontheguitar and @sulikomusic will perform at the musical apartment. The event will be hosted by Zhanserik Kadyrbayev (@kadyrbayev_). What to take with you to the glamping festival U: DACHA? Warm clothes; A blanket; Your mug; A camera; A good mood; An identity card. Source https://the-steppe.com/gorod/v-shymkente-sostoitsya-pervyy-glemping-festival-u-dacha</p>','<p>Глэмпинг дегеніміз не? Глэмпинг-гламур және кемпинг сөздерінің туындысы. Басқаша айтқанда, шатырдағы қонақ үй.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Демалудың бұл түрі рюкзактар мен қатал таулы жағдайларды стреске енгізетін адамдар үшін жасалған. Глэмпингтің жалғыз шарты - шатырдағы қонақ үй мобильді және қоршаған ортаға зиян келтірместен үйлесімді болуы керек. Қазақстанға бұл не үшін қажет? Біз &quot;маевка&quot; терминінен арылғымыз келеді, өйткені ол ескірген. Шын мәнінде, бұл сөз жұмысшы табының заңсыз жиналысын білдірді. Ал КСРО кезінде ол қандай да бір дайындық пен жайлылықсыз табиғатта демалу ұғымына айналды. Бүгінгі таңда адам қалалық экожүйеге соншалықты жақын, сондықтан ол мезгіл-мезгіл табиғатқа шығуы керек. Бұл мәселені шешу глампинг болуы мүмкін-қоршаған ортаға ешқандай зиян келтірместен ыңғайлы және сәнді демалысты білдіретін жаңа ұғым. Коронавирустық пандемияға байланысты мәдени шаралар тоқтатылды немесе кейінге қалдырылды. Шымкент тұрғындары үшін глэмпинг-ашық аспан астындағы іс-шараға қатысу мүмкіндіктерінің бірі. Табиғатта демалудың жаңа форматы ішкі туризмді дамытуға көмектеседі және адамдарды Түркістан облысының әсемдігімен таныстырады. Дәстүрлі мәдениет үлгілерін, мысалы, киіз үйлерді жаңа форматқа тарта отырып, ұйымдастырушылар өткен дәстүрлер мен қазіргі заманның жайлылығын біріктіргісі келеді. Глэмпинг фестивалінде не болады U: коттедж? Шымкенттен Қасқасу ауылындағы демалыс аймағына Трансфер; ашық аспан астындағы проекторда фильм көру; күніне үш рет тамақтану + маршмеллоу және қуырылған сосискалары бар алау; волейбол, арқан тартыс және алтыбақан ойындары; таңғы йога; өзен мен моншада шомылу; атмосфералық суреттерге арналған Фотозон; Шатырда, киіз үйде немесе жеке үйде түнеу; музыкалық пәтер. U:жазғы коттедж фестивалінде кім болады? Музыкалық пәтерде Мирас Жугунусов, ozenxo жапсырмасының музыканттары &mdash; @dudeontheguitar және @sulikomusic өнер көрсетеді. Іс-шараның жүргізушісі Жансерік Қадырбаев (@kadyrbayev_) болады. Глэмпинг фестиваліне не әкелу керек U: коттедж? Жылы киім; көрпе; өз үйірмесі; камера; жақсы көңіл-күй; жеке куәлік. Көзі https://the-steppe.com/gorod/v-shymkente-sostoitsya-pervyy-glemping-festival-u-dacha</p>','v-shymkente-sostoitsya-pervyy-glemping-festival-u-dacha','WG3nTLLtAl.jpg',1,'2021-08-22 03:02:15','2021-08-22 03:02:15'),(3,2,1,'Топ-8 советов туристу','Top 8 tips for tourists','Туристерге арналған ең жақсы 8 Кеңес','<p>Шымкент, как и любой другой город, имеет свои особенности и о некоторых из них туристам следует знать заранее. Сегодня мы представляем вам подборку лучших советов для туристов впервые приезжающих в наш солнечный город! 1. Как добраться с аэропорта до города С аэропорта до города можно добраться на автобусах №12, №12а, №12б. Автобусы курсируют с 6:00 до 19:00 (карантинное время). Стоимость поездки 100 тенге. Также, можно воспользоваться услугами такси Яндекс и местными службами такси: Такси Region &ndash; 8(701)3555555 Такси Mobil O.K. &ndash; 8(707)1155555, 8(701)0555555 Такси Mega Star &ndash; 2626, 8(776)0333555 2. Сим-карта и интернет Прилетая из других стран, вам выгоднее купить казахстанскую сим-карту. На сайте simka.kz вы сможете купить сим-карту с тарифным планом онлайн. Также сим-карты можно приобрести в магазинах сотовых операторов (Kcell, Beeline, Tele 2, Altel и прочие) в городе. Это значительно сэкономит ваши средства. В среднем месячный тариф обойдется в 3000 тенге. 3. Как ориентироваться по городу Выбирайте места посещения, маршруты на нашем портале. Из мобильных карт рекомендуем воспользоваться Картой Яндекс, одним из преимуществ которой являются точные маршруты. В добавок можете скачать приложение 2GIS, оно просто и удобно в использовании и содержит больше информации о городских объектах. 4. Аренда жилья Шымкент может предложить вам большое количество разнообразных отелей, с которыми можно ознакомиться на нашем сайте и приложении booking.com. В поиске апартаментов вам поможет приложение AirBnb. Но, если вы решите арендовать жилье на долгий срок, то посетите сайт krisha.kz. 5. Общественный транспорт В городе действует дифференцированная система оплаты в общественном транспорте, если выбираете этот вид передвижения , можете приобрести карту Толем за 500 тенге, стоимость проезда в таком случае составит 70 тенге, тогда как проезд без карты -100 тенге. 6. Аренда автомобилей Если вы планируете часто передвигаться по городу и длительные поездки на дальние расстояния, советуем вам рассмотреть вариант аренды автомобилей. Ниже вы можете ознакомиться со списком агентств по автопрокату. Royal Autorent www.avtoprokat-royal.kz www.toyota-shymkent.kz www.autoprokat-br.kz 7. Продуктовые магазины Продуктовых магазинов и разнообразных рынков в городе достаточно. За свежими овощами, фруктами и за мясной продукцией советуем идти на рынок, например, Верхний, Алаш или Айна. В каждом районе города можно найти маленькие бакалейные магазины, но стоит обратить внимание и на большие сети супермаркетов Фиркан, Магнум и Метро. 8. Экстренные службы В случае экстренной необходимости сохраните информацию ниже. 112 &ndash; телефонный номер единой дежурно &ndash; диспетчерской службы Департамента по чрезвычайным ситуациям. 101 &ndash; служба пожаротушения. 102 &ndash; полиция. 103 &ndash; скорая медицинская помощь. 104 &ndash; аварийная служба газа. С учётом всех обстоятельств, может оказаться более правильным звонить напрямую в определённую экстренную службу. При этом звонок на номер экстренной службы с любого телефона (мобильного, стационарного, общественного таксофона) для вас будет бесплатным. (Информация с портала egov.kz) 3033 &ndash; справочная аптек Europharma. 8(701)7776770 &ndash; сеть аптек Зерде. 8(771)6698346 &ndash; экстренная стоматология Неболит. 8(775)4817010 &ndash; стоматология Taza dent. 8(747)3180776 &ndash; стоматология Умит Стом. На нашем сайте можно ознакомиться с дополнительной информацией по указанным пунктам и не только.</p>','<p>Shymkent, like any other city, has its own peculiarities and tourists should know about some of them in advance. Today we present you a selection of the best tips for tourists coming to our sunny city for the first time! 1. How to get from the airport to the city From the airport to the city you can get by buses No. 12, No. 12a, No. 12b. Buses run from 6: 00 to 19: 00 (quarantine time). The cost of the trip is 100 tenge. You can also use Yandex taxi services and local taxi services: Taxi Region &ndash; 8 (701)3555555 Taxi Mobil O. K. &ndash; 8(707)1155555, 8(701)0555555 Mega Star Taxi&ndash; 2626, 8(776)0333555 2. SIM card and Internet Arriving from other countries, it is more profitable for you to buy a Kazakh SIM card. On the website simka.kz you can buy a SIM card with a tariff plan online. SIM cards can also be purchased in stores of mobile operators (Kcell, Beeline, Tele 2, Altel and others) in the city. This will significantly save your money. On average, the monthly tariff will cost 3000 tenge. 3. How to navigate around the city Choose places to visit, routes on our portal. From mobile maps, we recommend using the Yandex Map, one of the advantages of which is accurate routes. In addition, you can download the 2GIS application, it is simple and convenient to use and contains more information about urban objects. 4. Rental housing Shymkent can offer you a large number of different hotels, which can be found on our website and application booking.com. The AirBnb app will help you find apartments. But, if you decide to rent a house for a long time, then visit the website krisha.kz. 5. Public transport In the city there is a differentiated payment system in public transport, if you choose this type of transportation , you can purchase a Tolem card for 500 tenge, the fare in this case will be 70 tenge, while travel without a card is 100 tenge. 6. Car rental If you plan to move around the city often and long trips over long distances, we advise you to consider the option of renting a car. Below you can find a list of car rental agencies. Royal Autorent www.avtoprokat-royal.kz www.toyota-shymkent.kz www.autoprokat-br.kz 7. Grocery stores There are enough grocery stores and various markets in the city. For fresh vegetables, fruits and meat products, we recommend going to the market, for example, Verkhny, Alash or Aina. In every district of the city you can find small grocery stores, but it is worth paying attention to the large supermarket chains Firkan, Magnum and Metro. 8. Emergency Services In case of an emergency, save the information below. 112 is the phone number of the unified duty and dispatch service of the Department of Emergency Situations. 101 &ndash; fire extinguishing service. 102-the police. 103-emergency medical care. 104 - emergency gas service. Taking into account all the circumstances, it may be more correct to call directly to a certain emergency service. At the same time, a call to the emergency service number from any phone (mobile, landline, public payphone) will be free for you. (Information from the portal egov.kz) 3033-reference pharmacy Europharma. 8(701)7776770 - pharmacy chain Zerde. 8(771)6698346 - emergency dentistry is not painful. 8(775)4817010-Taza dent dentistry. 8(747)3180776-dentistry Umit Stom. On our website, you can find additional information on these items and not only.</p>','<p>Шымкент, кез-келген қала сияқты, өзінің сипаттамаларына ие және туристер олардың кейбіреулері туралы алдын-ала білуі керек. Бүгін біз сіздерге біздің шуақты қалаға алғаш рет келген туристерге арналған ең жақсы кеңестердің таңдауын ұсынамыз! 1. Әуежайдан қалаға қалай жетуге болады әуежайдан қалаға №12, №12а, №12б автобустармен жетуге болады. автобустар 6:00-ден 19:00-ге дейін жүреді (карантин уақыты). Сапар құны 100 теңге. Сондай &ndash; ақ, Яндекс такси қызметтерін және жергілікті такси қызметтерін пайдалануға болады: Такси Region-8(701)3555555 такси Mobil O. K. &ndash; 8(707)1155555, 8(701)0555555 Такси Mega Star&ndash; 2626, 8(776)0333555 2. Сим-карта және интернет басқа елдерден ұшып келе жатқанда, сізге қазақстандық сим-картаны сатып алған тиімдірек. Сайтта simka.kz сіз онлайн режимінде тарифтік жоспары бар SIM картасын сатып ала аласыз. Сондай-ақ сим-карталарды қаладағы ұялы байланыс операторларының дүкендерінен (Kcell, Beeline, Tele 2, Altel және басқалары) сатып алуға болады. Бұл сіздің ақшаңызды айтарлықтай үнемдейді. Орташа айлық тариф 3000 теңге тұрады. 3. Қала бойынша қалай бағдарлану керек біздің порталдағы баратын орындарды, маршруттарды таңдаңыз. Мобильді карталардан Яндекс картасын пайдалануды ұсынамыз, оның артықшылықтарының бірі нақты бағыттар болып табылады. Сонымен қатар, сіз 2gis қосымшасын жүктей аласыз, оны пайдалану оңай және ыңғайлы және қалалық нысандар туралы көбірек ақпарат бар. 4. Жалға берілетін тұрғын үй Шымкент сізге көптеген қонақ үйлерді ұсына алады, олармен біздің сайтта және қосымшада танысуға болады booking.com. пәтер іздеуде сізге AirBnb қосымшасы көмектеседі. Бірақ, егер сіз тұрғын үйді ұзақ мерзімге жалға беруді шешсеңіз, сайтқа кіріңіз krisha.kz. 5. Қоғамдық көлік қалада қоғамдық көлікте ақы төлеудің сараланған жүйесі жұмыс істейді, егер сіз қозғалыстың осы түрін таңдасаңыз , төлем картасын 500 теңгеге сатып ала аласыз, мұндай жағдайда жол жүру құны 70 теңгені құрайды, ал картасыз жол жүру-100 теңге. 6. Автокөлік жалдау егер сіз қала бойынша жиі саяхаттауды және ұзақ қашықтыққа сапарларды жоспарласаңыз, сізге автокөлік жалдау опциясын қарастыруға кеңес береміз. Төменде сіз автопрокат жөніндегі агенттіктердің тізімімен таныса аласыз. Royal Autorent www.avtoprokat-royal.kz www.toyota-shymkent.kz www.autoprokat-br.kz 7. Азық-түлік дүкендері қаладағы азық-түлік дүкендері мен түрлі базарлар жеткілікті. Жаңа піскен көкөністер, жемістер мен ет өнімдері үшін базарға баруға кеңес береміз, мысалы, жоғарғы, Алаш немесе Айна. Қаланың әр ауданында сіз шағын азық-түлік дүкендерін таба аласыз, бірақ сіз Фиркан, Магнум және Метро супермаркеттерінің үлкен желілеріне назар аударуыңыз керек. 8. Төтенше жағдайлар қызметтері шұғыл қажет болған жағдайда төмендегі ақпаратты сақтаңыз. 112 &ndash; Төтенше жағдайлар департаменті Бірыңғай кезекші-диспетчерлік қызметінің телефон нөмірі. 101-өрт сөндіру қызметі. 102-полиция. 103-Жедел медициналық көмек. 104-авариялық газ қызметі. Барлық жағдайларды ескере отырып, белгілі бір жедел қызметке тікелей қоңырау шалу дұрыс болуы мүмкін. Бұл ретте кез келген телефоннан (мобильді, стационарлық, қоғамдық таксофоннан) шұғыл қызмет нөміріне қоңырау шалу тегін болады. (Порталдан ақпарат egov.kz) 3033-Europharma анықтама дәріханасы. 8 (701) 7776770-Зерде дәріханалар желісі. 8 (771) 6698346-шұғыл стоматология нашар. 8 (775) 4817010 &ndash; Taza Dent стоматологиясы. 8 (747) 3180776-Стоматология үміт Стом. Біздің сайтта көрсетілген тармақтар бойынша қосымша ақпаратпен ғана емес, танысуға болады.</p>','top-8-sovetov-turistu','TpdLvo10gl.jpg',1,'2021-08-22 03:05:41','2021-08-22 03:05:41'),(4,4,6,'10 классных предметов для кухни: с ними вы полюбите готовить','10 cool items for the kitchen: with them you will love to cook','Ас үйге арналған 10 керемет заттар: олармен бірге сіз тамақ дайындауды ұнатасыз','<p>Современные кухонные девайсы не только ускоряют процесс подготовки и экономят время, но и скрашивают быт. Рассказываем, чем они так хороши.<br />\r\nНабор разделочных досок</p>\r\n\r\n<p>В одном таком наборе четыре доски для разных продуктов: рыбы, мяса, хлеба, фруктов и овощей. И в каждой из них свои особенности. Например, в хлебной дружке имеют канавки для крошек, а держать рыбку во время разделки помогают выпученные бугорки на середине доски.</p>\r\n\r\n<p>Все доски удобно хранится в специальной стильной подставке. Чтобы не путаться в их назначении, смотрите на красочные ярлыки с подсказками.</p>','<p>Modern kitchen devices not only speed up the preparation process and save time, but also brighten up everyday life. We tell you why they are so good.<br />\r\nA set of cutting boards</p>\r\n\r\n<p>In one such set there are four boards for different products: fish, meat, bread, fruits and vegetables. And each of them has its own characteristics. For example, in a bread basket there are grooves for cats, and bulging bumps in the middle of the board help to keep the fish during cutting.</p>\r\n\r\n<p>All the boards are conveniently stored in a special stylish stand. In order not to get confused about their purpose, look at the colorful labels with hints.</p>','<p>Қазіргі заманғы ас үй девайсы ғана тездетеді дайындау процесі және уақыт үнемдейді, бірақ скрашивают тұрмысы. Айтамыз, олар да жақсы.<br />\r\nКесу тақталарының жиынтығы</p>\r\n\r\n<p>Осындай жиынтықтың бірінде әртүрлі өнімдерге арналған төрт тақтай бар: балық, ет, нан, жемістер мен көкөністер. Олардың әрқайсысының өзіндік ерекшеліктері бар. Мысалы, нан досында мысықтарға арналған ойықтар бар, ал кесу кезінде балықты ұстауға тақтаның ортасындағы түйнектер көмектеседі.</p>\r\n\r\n<p>Барлық тақталар арнайы стильді стендте ыңғайлы сақталады. Олардың мақсаты туралы шатастырмау үшін түрлі-түсті жапсырмаларды қараңыз.</p>','10-klassnyh-predmetov-dlya-kuhni-s-nimi-vy-polyubite-gotovit','Qxle7RRBsX.jpg',1,'2021-08-27 23:58:08','2021-08-28 00:06:15'),(5,2,5,'13 мест, которые должны попасть в ваш Instagram','13 places that should get into your Instagram','Instagram - ға кіру керек 13 орын','<p>Современные проблемы требуют современных решений. Проблема локаций для крутых фото в Instagram актуальна как никогда. Сегодня, мы предлагаем вам список самых крутых мест для фотографий в Шымкенте.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;1. Колесо обозрения &laquo;Altyn Eye&raquo; Локация: Площадь Наурыз Начните инста-прогулку с просмотра города на колесе обозрения. Сделайте пару снимков на высоте и обязательно обзаведитесь фото на фоне колеса. Колесо очень фотогенично, особенно ночью.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>2. Набережная реки Кошкар Ата Локация: Аль-Фарабийский район Прогуляйтесь по набережной и сфотографируйте необычайную красоту природы и себя на фоне.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>3. Мост влюбленных Локация: Дендропарк Хотите романтичных фото? Вам на мост влюбленных! 4. Инсталляция &laquo;Qyzgaldaq&raquo; Локация: Дендропарк В дендропарке много локация для фото помимо моста, например, инсталляция &laquo;Qyzgaldaq&raquo; наверняка, привлечет ваше внимание.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>5. Рельсы старой детской железной дорожки Локация: Дендропарк А еще обязательно посмотрите на рельсы старой детской железной дороги. Можно сделать фото как из сказки! 6. Мурал &laquo;Кыз-Жибек&raquo; Локация: Пешеходная зона по ул. Бейбитшилик (Арбат) Фото на фоне муралов выглядят особенно красиво, поспешите к Муралу &laquo;Кыз-Жибек&raquo; чтобы разбавить свою ленту необычным снимком.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>7. Мурал &laquo;Тюльпан&raquo; Локация: ул. Назарбекова №210 Больше цветов в ленту! Добавьте фото с муралом &laquo;Тульпаны&raquo; в коллекцию снимков цветов.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>8. Фонтан &laquo;Тюльпан&raquo; Локация: угол пр. Тауке Хана и пр. Б. Момышулы А если вам понравятся тюльпаны, обязательно посетите одноименный фонтан. Красный тюльпан точно добавит красок в ваш профиль.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>9. Фонтан &laquo;Одуванчик&raquo; Локация: Центральный Парк Продолжая цветочную тему, сделайте снимок на фоне фонтана &laquo;Одуванчик&raquo;, а заодно отдохните от долгой, но продуктивной прогулки.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>10. Стена старого здания в парке металлургов Локация: Парк Металлургов Набравшись сил, направьтесь в Парк Металлургов. Найдите живописную стену старого здания в парке и сделайте пару атмосферных снимков.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>11. Зона &laquo;Африка&raquo; Локация: Зоопарк Фото с сафари находясь в Шымкенте? Легко! Бегом в зоопарк на зону Африка!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>12. Памятника Байдибек би Локация: ул. Байдибек би Возможно, снимок с памятником может показаться скучной идеей, но лестницы, ведущие к памятнику, однозначно стоит запечатлеть!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>13. Инсталляция &laquo;Love Shymkent&raquo; Локация: пр. Аль-Фараби, вход на Арбат Ну и как без визитки любого крутого города? На проспекте Аль-Фараби у входа на Арбат вы найдёте инсталляцию &laquo;Love Shymkent&raquo;. Такой снимок обязан у вас появится после поездки в солнечный город Шымкент!</p>','<p>Modern problems require modern solutions. The problem of locations for cool photos on Instagram is more relevant than ever. Today, we offer you a list of the coolest places to take photos in Shymkent.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>1. Ferris Wheel &quot;Altyn Eye&quot; Location: Nauryz Square Start your insta-walk by viewing the city on the Ferris wheel. Take a couple of pictures at a height and be sure to get a photo on the background of the wheel. The wheel is very photogenic, especially at night.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>2. Koshkar Ata River Embankment Location: Al-Farabi district Take a walk along the embankment and take a picture of the extraordinary beauty of nature and yourself against the background.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>3. Bridge of Lovers Location: Arboretum Do you want romantic photos? To you on the bridge of lovers! 4. Installation &quot;Qyzgaldaq&quot; Location: Arboretum In the arboretum there are many locations for photos in addition to the bridge, for example, the installation &quot;Qyzgaldaq&quot; will surely attract your attention.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>5. Rails of the old children&#39;s railway track Location: Arboretum And also be sure to look at the rails of the old children&#39;s railway. You can make a photo like from a fairy tale! 6. Mural &quot;Kyz-Zhibek&quot; Location: Pedestrian zone on Beibitshilik Street (Arbat) Photos against the background of murals look especially beautiful, hurry up to the Mural &quot;Kyz-Zhibek&quot; to dilute your tape with an unusual picture.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>7. Mural &quot;Tulip&quot; Location: No. 210 Nazarbekov str. More flowers in the ribbon! Add a photo with the mural &quot;Tulpany&quot; to the collection of pictures of flowers.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>8. Fountain &quot;Tulip&quot; Location: corner of Tauke Khan Ave. and B. Momyshuly Ave. And if you like tulips, be sure to visit the fountain of the same name. The red tulip will definitely add colors to your profile.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>9. Fountain &quot;Dandelion&quot; Location: Central Park Continuing the floral theme, take a picture against the background of the fountain &quot;Dandelion&quot;, and at the same time relax from a long but productive walk.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>10. The wall of an old building in the Park of Metallurgists Location: Park of Metallurgists Having gained strength, go to the Park of Metallurgists. Find a picturesque wall of an old building in the park and take a couple of atmospheric pictures.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>11. Zone &quot;Africa&quot; Location: Zoo Photo with safari while in Shymkent? Easy! Run to the zoo on the Africa zone!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>12. Baidibek bi Monument Location: Baidibek bi Street Perhaps a picture with a monument may seem like a boring idea, but the stairs leading to the monument are definitely worth capturing!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>13. Installation &quot;Love Shymkent&quot; Location: Al-Farabi Ave., entrance to the Arbat Well, how can it be without a business card of any cool city? On Al-Farabi Avenue at the entrance to the Arbat you will find the installation &quot;Love Shymkent&quot;. Such a picture is bound to appear after a trip to the sunny city of Shymkent!</p>','<p>Қазіргі проблемалар заманауи шешімдерді қажет етеді. Instagram-да керемет фотосуреттерге арналған орын мәселесі бұрынғыдан да өзекті. Бүгін біз сіздерге Шымкенттегі ең керемет фотосуреттер тізімін ұсынамыз.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>1. &quot;Altyn Eye&quot; шолу дөңгелегі орналасқан жері: Наурыз алаңы, шолу дөңгелегінде қаланы көруден инста-серуенді бастаңыз. Биіктікте бірнеше суретке түсіріңіз және дөңгелектің фонында суретке түсуді ұмытпаңыз. Доңғалақ өте фотогендік,әсіресе түнде.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>2. Қошқар Ата өзенінің жағалауы орналасқан жері: әл-Фараби ауданы жағалаумен серуендеп, табиғаттың ерекше сұлулығы мен фонында өзіңізді суретке түсіріңіз.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>3. Көпір ғашықтар Шектеу: Дендропарк Сіз романтикалық фото? Сіз ғашықтар көпірінде! 4. &quot;Qyzgaldaq&quot; қондырғысы орналасқан жері: дендропарк дендропаркта көпірден басқа фотосуреттер үшін көп орын бар, мысалы, &quot;Qyzgaldaq&quot; қондырғысы Сіздің назарыңызды аударады.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>5. Ескі балалар темір жолының рельстері орналасқан жері: Дендропарк және ескі балалар темір жолының рельстеріне назар аударыңыз. Сіз ертегі сияқты суретке түсе аласыз! 6. Мурал&quot; Қыз-Жібек &quot;Локация: Бейбітшілік (Арбат) көшесіндегі жаяу жүргіншілер аймағы муралдардың фонында ерекше әдемі көрінеді, лентаңызды ерекше суретке түсіру үшін&quot; Қыз-Жібек &quot; Муралына асығыңыз.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>7. Мурал &quot;Тюльпан&quot; Локация: Назарбеков көшесі №210 лентаға көбірек гүлдер! Түс суреттер жинағына мурал &quot;Тулпан&quot; суретін қосыңыз.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>8. &quot;Тюльпан&quot; фонтаны орналасқан жері: Тәуке хан даңғылы мен Б.Момышұлы даңғылының қиылысы, егер сізге қызғалдақтар ұнаса, міндетті түрде аттас фонтанға барыңыз. Қызыл қызғалдақ сіздің профиліңізге түстер қосады.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>9. &quot;Одуванчик&quot; фонтаны орналасқан жері: Орталық саябақ гүл тақырыбын жалғастыра отырып, &quot;Одуванчик&quot; фонтанының фонында суретке түсіріңіз, сонымен бірге ұзақ, бірақ нәтижелі серуендеуден демалыңыз.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>10. Металлургтер саябағындағы ескі ғимараттың қабырғасы орналасқан жері: Металлургтер паркі күш жинап, Металлургтер саябағына барыңыз. Саябақтағы ескі ғимараттың көркем қабырғасын тауып, бірнеше атмосфералық суретке түсіріңіз.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>11. &quot;Африка&quot; аймағы Локация: Зоопарк фото с сафари находящая в Шымкенте? Оңай! Африка аймағына хайуанаттар бағына жүгіру!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>12. Бәйдібек би ескерткіші орналасқан жері: Бәйдібек би көшесі ескерткіштің суреті скучно көрінуі мүмкін, бірақ ескерткішке апаратын баспалдақтарды міндетті түрде түсірген жөн!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>13. &quot;Love Shymkent&quot; инсталляциясы орналасқан жері: әл-Фараби даңғылы, Арбат көшесіне кіру және кез келген тік қаланың визиткасынсыз қалай? Арбат кіреберісіндегі Әл-Фараби даңғылында сіз &quot;Love Shymkent&quot;инсталляциясын таба аласыз. Мұндай сурет сіздің Шымкенттің шуақты қаласына барғаннан кейін пайда болуы керек!</p>','13-mest-kotorye-dolzhny-popast-v-vash-instagram','7zYWoJ7Dkk.jpg',1,'2021-08-27 23:59:49','2021-08-28 00:00:32'),(6,3,6,'LOREM IPSUM DOLORES','LOREM IPSUM DOLORES','LOREM IPSUM DOLORES','<p>LOREM IPSUM DOLORES LOREM IPSUM DOLORES</p>','<p>LOREM IPSUM DOLORES V</p>','<p>LOREM IPSUM DOLORES LOREM IPSUM DOLORES</p>','lorem-ipsum-dolores',NULL,0,'2021-08-28 00:11:27','2021-08-28 00:11:27');
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned DEFAULT NULL,
  `event_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_events_category_id_foreign` (`category_id`),
  KEY `categories_events_event_id_foreign` (`event_id`),
  CONSTRAINT `categories_events_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categoryevents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `categories_events_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories_events` WRITE;
/*!40000 ALTER TABLE `categories_events` DISABLE KEYS */;
INSERT INTO `categories_events` VALUES (4,5,4,'2021-08-22 01:06:03','2021-08-22 01:06:03'),(5,6,5,'2021-08-22 01:18:04','2021-08-22 01:18:04'),(6,3,6,'2021-08-28 23:59:11','2021-08-28 23:59:11'),(8,3,7,'2021-08-29 00:43:28','2021-08-29 00:43:28'),(9,4,7,'2021-08-29 00:43:36','2021-08-29 00:43:36'),(10,5,8,'2021-08-29 00:53:31','2021-08-29 00:53:31');
/*!40000 ALTER TABLE `categories_events` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories_places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories_places` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned NOT NULL,
  `place_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_places_category_id_foreign` (`category_id`),
  KEY `categories_places_place_id_foreign` (`place_id`),
  CONSTRAINT `categories_places_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categoryplaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `categories_places_place_id_foreign` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories_places` WRITE;
/*!40000 ALTER TABLE `categories_places` DISABLE KEYS */;
INSERT INTO `categories_places` VALUES (3,2,5,'2021-08-22 00:27:13','2021-08-22 00:27:13'),(4,19,5,'2021-08-22 00:35:32','2021-08-22 00:35:32'),(5,2,6,'2021-08-22 00:53:20','2021-08-22 00:53:20'),(6,10,6,'2021-08-22 00:53:53','2021-08-22 00:53:53'),(7,2,7,'2021-08-22 00:58:23','2021-08-22 00:58:23'),(8,20,7,'2021-08-22 00:58:23','2021-08-22 00:58:23'),(9,2,8,'2021-08-22 01:09:19','2021-08-22 01:09:19'),(10,18,8,'2021-08-22 01:09:19','2021-08-22 01:09:19'),(11,6,11,'2021-08-22 01:38:04','2021-08-22 01:38:04');
/*!40000 ALTER TABLE `categories_places` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categoryevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoryevents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categoryevents` WRITE;
/*!40000 ALTER TABLE `categoryevents` DISABLE KEYS */;
INSERT INTO `categoryevents` VALUES (3,'Ярмарка','Жәрмеңке','Fair','yarmarka',NULL,1,'2021-08-22 01:01:46','2021-08-22 01:01:46'),(4,'Спортивное мероприятие','Спорттық іс-шара','Sports event','sportivnoe-meropriyatie',NULL,1,'2021-08-22 01:02:27','2021-08-22 01:02:27'),(5,'Экскурсия','Экскурсия','Excursion','ekskursiya',NULL,1,'2021-08-22 01:03:32','2021-08-22 01:03:32'),(6,'Городские объекты','Қалалық Нысандар','Urban objects','gorodskie-obekty',NULL,1,'2021-08-22 01:14:16','2021-08-22 01:14:16');
/*!40000 ALTER TABLE `categoryevents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categorynews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorynews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categorynews` WRITE;
/*!40000 ALTER TABLE `categorynews` DISABLE KEYS */;
INSERT INTO `categorynews` VALUES (2,'Новости Шымкента','Shymkent news','Шымкент жаңалықтары','novosti-shymkenta',NULL,1,'2021-08-22 02:51:12','2021-08-22 02:51:12'),(3,'Другие Новости','Other news','Басқа жаңалықтар','drugie-novosti',NULL,1,'2021-08-22 02:51:37','2021-08-22 02:51:37');
/*!40000 ALTER TABLE `categorynews` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categoryplaces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoryplaces` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint unsigned DEFAULT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categoryplaces_parent_id_foreign` (`parent_id`),
  CONSTRAINT `categoryplaces_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categoryplaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categoryplaces` WRITE;
/*!40000 ALTER TABLE `categoryplaces` DISABLE KEYS */;
INSERT INTO `categoryplaces` VALUES (2,NULL,'Городские объекты','Қалалық Нысандар','Urban objects','gorodskie-obekty','hx5d5m5a3S.jpg',1,'2021-08-21 23:37:43','2021-08-21 23:37:43'),(3,NULL,'Культура и искусство','Мәдениет және өнер','Culture and art','kultura-i-iskusstvo','mexrE2CGvh.jpg',1,'2021-08-21 23:39:23','2021-08-21 23:39:23'),(4,NULL,'Истории и Традиции','Тарих және дәстүр','Stories and Traditions','istorii-i-tradicii','1aZ4JCamfr.jpg',1,'2021-08-21 23:40:53','2021-08-21 23:40:53'),(5,NULL,'Экологический туризм','Экологиялық туризм','Eco-tourism','ekologicheskiy-turizm','u40uOGtqTL.png',1,'2021-08-21 23:42:05','2021-08-21 23:42:05'),(6,NULL,'Гастрономический туризм','Гастрономиялық туризм','Gastronomic tourism','gastronomicheskiy-turizm','oz5pCAXypq.jpg',1,'2021-08-21 23:43:46','2021-08-21 23:43:46'),(7,NULL,'Активный отдых','Белсенді демалыс','Active recreation','aktivnyy-otdyh','eC9F8fQdQE.jpg',1,'2021-08-21 23:52:46','2021-08-21 23:52:46'),(8,NULL,'Туркестан и Отырар','Туркестан және Отырар','Turkestan and Otyrar','turkestan-i-otyrar','02lRYdbvsT.jpg',1,'2021-08-21 23:57:43','2021-08-21 23:57:43'),(9,NULL,'Туристический сервис','Туристік сервис','Tourist service','turisticheskiy-servis','QPPtNJ9Poa.jpg',1,'2021-08-22 00:09:48','2021-08-22 00:09:48'),(10,NULL,'Шоппинг','Шоппинг','Shopping','shopping','xf5EQqmyZZ.jpg',1,'2021-08-22 00:10:52','2021-08-22 00:10:52'),(11,NULL,'Лечебный и оздоровительный центр','Емдеу және сауықтыру орталығы','Medical and wellness center','lechebnyy-i-ozdorovitelnyy-centr','EJboSIIoiS.jpg',1,'2021-08-22 00:12:14','2021-08-22 00:12:14'),(12,NULL,'Отели и гостиницы','Қонақ үйлер мен қонақ үйлер','Hotels and inns','oteli-i-gostinicy','jbWR5kWDy8.jpg',1,'2021-08-22 00:13:23','2021-08-22 00:13:23'),(13,NULL,'Деловой туризм','Іскерлік туризм','Business tourism','delovoy-turizm','oRcY9E31df.jpg',1,'2021-08-22 00:14:24','2021-08-22 00:14:25'),(14,4,'Исторические места','Тарихи орындар','Historical places','istoricheskie-mesta',NULL,1,'2021-08-22 00:15:36','2021-08-22 00:15:36'),(15,4,'Сакральные места','Қасиетті орындар','Sacred places','sakralnye-mesta',NULL,1,'2021-08-22 00:16:30','2021-08-22 00:16:30'),(16,4,'Традиции и обряды','Дәстүрлері мен әдет','Traditions and rituals','tradicii-i-obryady',NULL,1,'2021-08-22 00:21:19','2021-08-22 00:21:19'),(17,4,'Музеи','Мұражайлар','Museums','muzei',NULL,1,'2021-08-22 00:22:24','2021-08-22 00:22:24'),(18,5,'Национальные парки','Ұлттық парктер','National parks','nacionalnye-parki',NULL,1,'2021-08-22 00:23:15','2021-08-22 00:23:15'),(19,2,'Парки и фонтаны','Саябақтар мен субұрқақтар','Parks and fountains','parki-i-fontany',NULL,1,'2021-08-22 00:24:07','2021-08-22 00:24:07'),(20,2,'Памятники и сооружения','Ескерткіштер мен құрылыстар','Monuments and structures','pamyatniki-i-sooruzheniya',NULL,1,'2021-08-22 00:24:54','2021-08-22 00:24:54');
/*!40000 ALTER TABLE `categoryplaces` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emails` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `emails` WRITE;
/*!40000 ALTER TABLE `emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `emails` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `event_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_types` WRITE;
/*!40000 ALTER TABLE `event_types` DISABLE KEYS */;
INSERT INTO `event_types` VALUES (1,'Мероприятие','Іс-шара','Activity','2021-08-21 04:09:03','2021-08-21 04:09:03'),(2,'Услуга','Қызмет','Service','2021-08-21 04:09:03','2021-08-21 04:09:03');
/*!40000 ALTER TABLE `event_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `organizator_id` bigint unsigned DEFAULT NULL,
  `place_id` bigint unsigned DEFAULT NULL,
  `type_id` bigint unsigned NOT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_ru` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_kz` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `eventum` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` json DEFAULT NULL,
  `social_networks` json DEFAULT NULL,
  `sites` json DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_link` longtext COLLATE utf8mb4_unicode_ci,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `events_organizator_id_foreign` (`organizator_id`),
  KEY `events_place_id_foreign` (`place_id`),
  KEY `events_type_id_foreign` (`type_id`),
  CONSTRAINT `events_organizator_id_foreign` FOREIGN KEY (`organizator_id`) REFERENCES `organizators` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `events_place_id_foreign` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `events_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `event_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (4,NULL,NULL,2,'Экскурсия по городу Шымкент на двухэтажном автобусе','Шымкент қаласы бойынша екі қабатты автобуспен Экскурсия','Shymkent city tour by double-decker bus','<p>Незабываемые экскурсии по городу Шымкент на двухэтажном автобусе - Шымкент в четырех метрах от земли &mdash; экскурсия по самым красивым местам любимого города никого не оставит равнодушными. Мимо вас &laquo;пронесутся&raquo; главные достопримечательности города, будет рассказано об истории практически каждого здания, объекта расположенного на главных улицах Шымкента. Думаем, вы оцените хорошее чувство юмора, профессионализм и разносторонность экскурсовода, и это будут очень познавательные, веселые, полезные 2 часа, незабываемая экскурсия в вашей жизни.</p>','<p>Екі қабатты автобуспен Шымкент қаласына ұмытылмас экскурсиялар - жерден төрт метр қашықтықта орналасқан Шымкент-сүйікті қаланың ең әдемі жерлеріне саяхат ешкімді бей-жай қалдырмайды. Сіздердің қасыңыздан қаланың басты көрікті жерлері &quot;өтеді&quot;, Шымкенттің басты көшелерінде орналасқан әрбір ғимараттың, объектінің тарихы туралы айтылады. Сіз әзіл-оспақ сезімін, гидтің кәсібилігі мен жан-жақтылығын бағалайсыз деп ойлаймыз және бұл сіздің өміріңіздегі өте мазмұнды, көңілді, пайдалы 2 сағат, ұмытылмас экскурсия болады.</p>','<p>Unforgettable excursions around the city of Shymkent on a double-decker bus-Shymkent is four meters from the ground &mdash; a tour of the most beautiful places of your favorite city will not leave anyone indifferent. The main sights of the city will &quot;rush&quot; past you, the history of almost every building, object located on the main streets of Shymkent will be told. We think you will appreciate the good sense of humor, professionalism and versatility of the guide, and it will be a very informative, fun, useful 2 hours, an unforgettable excursion in your life.</p>','ekskursiya-po-gorodu-shymkent-na-dvuhetazhnom-avtobuse',NULL,'[\"+77026943779\"]',NULL,NULL,'Арбат',NULL,NULL,'fWzcJQF64r.png',1,'2021-08-22 01:06:03','2021-08-22 01:06:15'),(5,NULL,NULL,1,'Государственный зоологический парк города Шымкент','Шымкент қаласының мемлекеттік зоологиялық паркі','Shymkent State Zoological Park','<p>Посещение государственного зоологического парка города Шымкент. Из общей площади зоопарка в 29 гектар, под экспозицией 29 гектар. В зоопарке содержится более 20 видов животных занесенных в красную книгу. 25 % потребностей в кормах для животных зоопарк покрывает за счёт собственной земли, площадью 29 гектар.</p>','<p>Шымкент қаласының мемлекеттік зоологиялық паркіне бару. Хайуанаттар бағының жалпы ауданы 29 гектар, экспозиция астында 29 гектар. Хайуанаттар бағында Қызыл кітапқа енгізілген жануарлардың 20-дан астам түрі бар. Хайуанаттар бағы жануарларға арналған жемге қажеттіліктің 25% - ын 29 гектар өз жері есебінен жабады.</p>','<p>Visit to the State Zoological Park of the city of Shymkent. Of the total area of the zoo of 29 hectares, under the exposition of 29 hectares. The zoo contains more than 20 species of animals listed in the Red Book. The zoo covers 25 % of the needs for animal feed at the expense of its own land, with an area of 29 hectares.</p>','gosudarstvennyy-zoologicheskiy-park-goroda-shymkent',NULL,NULL,NULL,NULL,'проспект Байдибек би 113/1','[{\"lat\":42.327458477871,\"lng\":69.70104217529298},{\"lat\":42.3794703483142,\"lng\":69.6248245239258}]',NULL,'3iLkpFEVo8.jpg',1,'2021-08-22 01:18:03','2021-08-22 01:18:04'),(6,NULL,NULL,1,'Конкурс стартапов в Шымкенте \"Я начинаю свое дело\"','Шымкентте \"Мен өз ісімді бастаймын\"стартаптар байқауы','Startup competition in Shymkent \"I\'m starting my own business\"','<p>Многие из нас в юности думали: - Вот бы у меня было 10 000 тенге, я бы сделал/а то и сделал/а это... Но все так и осталось несбыточным. Если у вас есть небольшой и перспективный бизнес проект, тогда торопитесь! У вас есть возможность воплотить его с @startup.shymkent Рассматриваются бизнес инвестирование в проекты: 5 проектов по 50 000 тг; 3 проектов по 100 000 тг; 2 проекта по 200 000 тг. Условия конкурса: 1. В проекте могут принять участие молодые люди из Шымкента от 16 до 23 лет. 2. Иметь огромное желание сделать необходимое для успеха своего проекта. 3. Быть подписанным на @startup.shymkent, отметить 5 друзей под этим постом. 4. Отправьте в Direct свою электронную почту и мы с вами обязательно свяжемся! Всем успехов и хорошего начала в 2021 году!</p>','<p>Жас кезімізде көбіміз: - Менде 10 000 теңге болғанын қалаймын, мен жасайтынмын / тіпті жасайтын да едім, бірақ ... Бірақ бәрі іске асырылмай қалды. Егер сізде шағын және болашағы зор бизнес-жоба болса, онда асығыңыз! Сізде оны @ startup.shymkent арқылы жүзеге асыруға мүмкіндік бар Жобаларға бизнесті инвестициялау қарастырылуда: 50 000 теңгеге 5 жоба; 100000 теңгеге 3 жоба; 200000 теңгеге 2 жоба. Байқау шарттары: 1. Жобаға 16 мен 23 жас аралығындағы шымкенттік жастар қатыса алады. 2. Жобаңыздың сәтті болуы үшін қажет нәрсені жасауға деген үлкен ниетіңіз болуы керек. 3. @ startup.shymkent-ке жазылыңыз, осы посттың астына 5 досыңызды белгілеңіз. 4. Электрондық поштаңызды Direct-ке жіберіңіз, сонда біз сізге хабарласамыз! Барлық жетістіктер және 2021 жылы жақсы бастама!</p>','<p>Many of us in our youth thought: - If I had 10,000 tenge, I would have done/and done/and this... But everything remained unrealizable. If you have a small and promising business project, then hurry up! You have the opportunity to implement it with @startup.shymkent Business investment in projects is considered: 5 projects of 50,000 tenge; 3 projects of 100,000 tenge; 2 projects of 200,000 tenge. Terms of the competition: 1.Young people from Shymkent from 16 to 23 years old can take part in the project. 2. Have a great desire to do what is necessary for the success of your project. 3. Be subscribed to @startup.shymkent, mark 5 friends under this post. 4. Send your email to Direct and we will definitely contact you! We wish you all success and a good start in 2021!</p>','konkurs-startapov-v-shymkente-ya-nachinayu-svoe-delo',NULL,NULL,NULL,NULL,'ул.Желтоксан 17','[{\"lat\":42.32382872992761,\"lng\":69.6086883544922}]','Бесплатно','i39eRr6caE.jpg',1,'2021-08-28 23:59:11','2021-08-28 23:59:11'),(7,NULL,NULL,1,'Бесплатное обучение СТЕНДОВОЙ СТРЕЛЬБЕ','Стендтік атуды тегін оқыту','Free training in BENCH SHOOTING','<p>Детско - юношеская спортивная школа по стрелковым видам спорта г. Шымкент объявляет о наборе учащихся с 12 по 16 лет на отделение СТЕНДОВОЙ СТРЕЛЬБЫ ⠀ Занятия проходят абсолютно 💰 БЕСПЛАТНО! ⠀ Стендовая стрельба - один из подвидов стрелкового спорта. Стрельба ведётся из гладкоствольных ружей дробовыми зарядами по специальным мишеням-тарелочкам. ⠀ 📌 Адрес: ул. Казыналы 90/1. ⠀ Справки по телефонам: 📞 +7 701 231 14 99 - Виталий Игоревич 📞 +7 705 150 22 90 - Евгений Викторович 📞 +7 775 307 66 11 - Андрей Сергеевич</p>','<p>Жиынтығы - жасөспірімдер спорт мектебі атқыш смотреть спорттық жарыстар миссис. Шымкент стенд ату бөлімшесі 16-рейске s 12 оқушысын қабылдайтынын хабарлайды ⠀ сабақтар тегін өтеді!&nbsp; ⠀ Стендтік ату - атыс қаруының бір түрі спортпен айналысады. Атыс тегіс ұңғылы мылтықтардан арнайы нысана-тәрелке бойынша бытыралы зарядтармен жүргізіледі.&nbsp; ⠀ ⠀ Мекен-жайы : қазыналы көшесі 90/1.&nbsp; ⠀ Анықтама телефондары: 📞 +7 701 231 14 99 - Виталий Игоревич 📞 +7 705 150 22 90 - Евгений Викторович 📞 +7 775 307 66 11 - Андрей Сергеевич</p>','<p>The children&#39;s and youth sports school for shooting sports in Shymkent announces the recruitment of students from 12 to 16 years old to the department of BENCH SHOOTING ⠀ Classes are absolutely FREE!&nbsp; Стенд Bench shooting is one of the subspecies of shooting sports. Shooting is carried out from smoothbore rifles with shotgun charges on special targets-skeet. ⠀ 📌 Address: 90/1 Kazynaly str.⠀ Information by phone: 📞 +7 701 231 14 99 - Vitaly Igorevich 📞 +7 705 150 22 90 - Eugene Viktorovich 📞 +7 775 307 66 11 - Andrew Sergeyevich</p>','besplatnoe-obuchenie-stendovoi-strelbe',NULL,'[\"+7 701 231 14 99\", \"+7 705 150 22 90\", \"+7 775 307 66 11\"]',NULL,NULL,'проспект Тауке хана 47/3',NULL,'Бесплатно','jLYwVPKX2w.jpg',1,'2021-08-29 00:42:47','2021-08-29 00:43:03'),(8,NULL,NULL,1,'Экскурсия по музею','Мұражайға саяхат','Museum tour','<p>Музей посвящен памяти людей, пострадавших от политических преследований и репрессий 1937-1938 годов. Он был торжественно открыт в ноябре 2001 года. Это событие было приурочено к празднованию десятилетия независимости государства. Здание музея возводилось по проекту заслуженного архитектора Казахстана Аманжола Найманбая. Экспозиция музея занимает два зала &ndash; это зал с экспонатами и зал скорби. Особое место отведено для галереи с портретами известных личностей Казахстана, а также обычных людей, которые пострадали от голода и репрессий в 1937-1938 годах. Здесь находятся портреты Ахмета Байтурсынова, Жусипбека Аймауытова, Мустафы Шокай, Турара Рыскулова, Мухамеджана Тынышпаева, Магжана Жумабаева и других великих людей. Посреди музея установлена скульптура &laquo;Репрессия&raquo;. По задумке авторов она отображает все муки и страдания, выпавшие на долю казахского народа в конце тридцатых годов ХХ века. Ежегодно музей посещают более пятнадцати тысяч человек. Работниками музея часто проводятся районные и городские мероприятия историко-просветительного характера.</p>','<p>Мұражай 1937-1938 жылдардағы саяси қуғын-сүргін мен қуғын-сүргіннен зардап шеккен адамдарды еске алуға арналған. Ол 2001 жылдың қараша айында салтанатты түрде ашылды. Бұл оқиға мемлекет тәуелсіздігінің онжылдығын мерекелеуге орайластырылды. Мұражай ғимараты Қазақстанның еңбек сіңірген сәулетшісі Аманжол Найманбайдың жобасы бойынша салынған. Мұражай экспозициясы екі залдан тұрады &ndash; бұл экспонаттары бар зал және қайғы залы. Галереяға Қазақстанның танымал тұлғаларының, сондай-ақ 1937-1938 жылдардағы ашаршылық пен қуғын-сүргіннен зардап шеккен қарапайым адамдардың портреттері қойылған. Мұнда Ахмет Байтұрсыновтың, Жүсіпбек Аймауытовтың, Мұстафа Шоқайдың, Тұрар Рысқұловтың, Мұхамеджан Тынышбаевтың, Мағжан Жұмабаевтың және басқа да ұлы тұлғалардың портреттері орналасқан. Мұражайдың ортасында &quot;Репрессия&quot; мүсіні тұр. Авторлардың ойы бойынша ол ХХ ғасырдың отызыншы жылдарының соңында қазақ халқының үлесіне тигеннің барлық азабы мен азабын бейнелейді. Жыл сайын мұражайға он бес мыңнан астам адам келеді. Мұражай қызметкерлері тарихи-ағартушылық сипаттағы аудандық және қалалық іс-шараларды жиі өткізеді.</p>','<p>The museum is dedicated to the memory of people who suffered from political persecution and repression in 1937-1938. It was officially opened in November 2001. This event was timed to coincide with the celebration of the decade of independence of the state. The museum building was built according to the project of the Honored architect of Kazakhstan Amanzhol Naimanbai. The museum&#39;s exposition occupies two halls - a hall with exhibits and a hall of sorrow. A special place is reserved for the gallery with portraits of famous personalities of Kazakhstan, as well as ordinary people who suffered from famine and repression in 1937-1938. There are portraits of Akhmet Baitursynov, Zhusipbek Aimauytov, Mustafa Shokai, Turar Ryskulov, Mukhamedzhan Tynyshpayev, Magzhan Zhumabayev and other great people here. In the middle of the museum there is a sculpture &quot;Repression&quot;. According to the authors &#39; idea, it reflects all the torments and sufferings that fell to the lot of the Kazakh people in the late thirties of the twentieth century. More than fifteen thousand people visit the museum every year. Employees of the museum often hold district and city events of a historical and educational nature.</p>','ekskursiya-po-muzeyu',NULL,NULL,NULL,NULL,'Рыскулбекова 14А',NULL,'Бесплатно','Tu5aV0D05z.jpg',1,'2021-08-29 00:53:31','2021-08-29 00:53:31');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `galleries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `galleries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `place_id` bigint unsigned DEFAULT NULL,
  `event_id` bigint unsigned DEFAULT NULL,
  `route_id` bigint unsigned DEFAULT NULL,
  `shop_id` bigint unsigned DEFAULT NULL,
  `souvenir_id` bigint unsigned DEFAULT NULL,
  `organizator_id` bigint unsigned DEFAULT NULL,
  `news_id` bigint unsigned DEFAULT NULL,
  `blog_id` bigint unsigned DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `galleries_place_id_foreign` (`place_id`),
  KEY `galleries_event_id_foreign` (`event_id`),
  KEY `galleries_route_id_foreign` (`route_id`),
  KEY `galleries_shop_id_foreign` (`shop_id`),
  KEY `galleries_souvenir_id_foreign` (`souvenir_id`),
  KEY `galleries_organizator_id_foreign` (`organizator_id`),
  KEY `galleries_news_id_foreign` (`news_id`),
  KEY `galleries_blog_id_foreign` (`blog_id`),
  CONSTRAINT `galleries_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galleries_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galleries_news_id_foreign` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galleries_organizator_id_foreign` FOREIGN KEY (`organizator_id`) REFERENCES `organizators` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galleries_place_id_foreign` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galleries_route_id_foreign` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galleries_shop_id_foreign` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galleries_souvenir_id_foreign` FOREIGN KEY (`souvenir_id`) REFERENCES `souvenirs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `galleries` WRITE;
/*!40000 ALTER TABLE `galleries` DISABLE KEYS */;
INSERT INTO `galleries` VALUES (1,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7r0LEoZC5O.jpg','2021-08-22 00:38:28','2021-08-22 00:38:28'),(2,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eqYQNZCFJW.jpg','2021-08-22 00:38:43','2021-08-22 00:38:43'),(3,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'cd2JEIXBO9.jpg','2021-08-22 00:38:52','2021-08-22 00:38:53'),(4,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'3MbQLaWY6b.jpg','2021-08-22 00:54:23','2021-08-22 00:54:23'),(5,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'VEWOrRcPfi.jpg','2021-08-22 00:54:37','2021-08-22 00:54:37'),(6,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'QGdtCsL5tN.jpg','2021-08-22 00:58:23','2021-08-22 00:58:23'),(7,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'BRVj8S4QwB.jpg','2021-08-22 00:58:23','2021-08-22 00:58:23'),(8,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'f3rKJevOZt.jpg','2021-08-22 00:58:23','2021-08-22 00:58:23'),(9,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'tQD59jrtMa.jpg','2021-08-22 01:10:51','2021-08-22 01:10:51'),(10,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'xpheFLw3wZ.jpg','2021-08-22 01:11:02','2021-08-22 01:11:02'),(11,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'cw8ZncxoSG.png','2021-08-22 01:30:50','2021-08-22 01:30:50'),(12,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TJah04VZsl.png','2021-08-22 01:30:50','2021-08-22 01:30:50'),(13,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Bqz1l5QhL0.png','2021-08-22 01:30:50','2021-08-22 01:30:50'),(14,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2bxi4fgS0f.jpg','2021-08-22 01:34:50','2021-08-22 01:34:50'),(15,11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'wyZpEFuOgt.png','2021-08-22 01:38:04','2021-08-22 01:38:04'),(16,11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'RsTSO15rgN.png','2021-08-22 01:38:04','2021-08-22 01:38:04'),(17,11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'gLNsj5aYpb.png','2021-08-22 01:38:04','2021-08-22 01:38:04'),(18,11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'JrgG643d1W.png','2021-08-22 01:38:04','2021-08-22 01:38:04'),(19,NULL,NULL,NULL,4,NULL,NULL,NULL,NULL,'SvjNZbtweh.jpg','2021-08-22 02:15:44','2021-08-22 02:15:44'),(20,NULL,NULL,NULL,4,NULL,NULL,NULL,NULL,'BbWwXwpZMJ.jpg','2021-08-22 02:15:44','2021-08-22 02:15:44'),(21,NULL,NULL,NULL,NULL,4,NULL,NULL,NULL,'PQuKeDnCyh.jpg','2021-08-22 02:27:32','2021-08-22 02:27:32'),(22,NULL,NULL,NULL,NULL,5,NULL,NULL,NULL,'8A66yYG7dv.jpg','2021-08-22 02:31:37','2021-08-22 02:31:37'),(23,NULL,NULL,NULL,NULL,6,NULL,NULL,NULL,'I36qFT0cXY.jpg','2021-08-22 02:35:48','2021-08-22 02:35:48'),(24,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,'WamhDRYoSU.jpg','2021-08-22 02:54:52','2021-08-22 02:54:52'),(25,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,'yWSKljAai0.jpg','2021-08-22 02:59:30','2021-08-22 02:59:30'),(26,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'8IZUOFmzlm.png','2021-08-22 03:02:15','2021-08-22 03:02:15'),(27,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'qKZ0eMl1G8.png','2021-08-22 03:02:15','2021-08-22 03:02:15'),(28,NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,'YI5pNBU2KW.jpg','2021-08-29 00:43:48','2021-08-29 00:43:48'),(29,NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,'YwG6kSaCJy.jpg','2021-08-29 00:53:31','2021-08-29 00:53:31');
/*!40000 ALTER TABLE `galleries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2021_07_15_071413_create_roles_table',1),(2,'2021_07_15_071917_create_weekdays_table',1),(3,'2021_07_15_072312_create_users_table',1),(4,'2021_07_15_072314_create_organizators_table',1),(5,'2021_07_15_072314_create_shops_table',1),(6,'2021_07_15_074035_create_recoveries_table',1),(7,'2021_07_15_074251_create_sliders_table',1),(8,'2021_07_15_074649_create_place_type_table',1),(9,'2021_07_15_074650_create_places_table',1),(10,'2021_07_15_075457_create_category_places_table',1),(11,'2021_07_15_075908_create_categories_places_table',1),(12,'2021_07_15_080211_create_event_types_table',1),(13,'2021_07_15_080213_create_events_table',1),(14,'2021_07_15_081249_create_category_events_table',1),(15,'2021_07_15_081410_create_categories_events_table',1),(16,'2021_07_15_082037_create_route_types_table',1),(17,'2021_07_15_082038_create_route_categories_table',1),(18,'2021_07_15_082040_create_routes_table',1),(19,'2021_07_15_082041_create_routes_types_table',1),(20,'2021_07_15_085352_create_souvenir_category',1),(21,'2021_07_15_085353_create_souvenirs_table',1),(22,'2021_07_15_090910_create_category_news_table',1),(23,'2021_07_15_090912_create_news_table',1),(24,'2021_07_15_092120_create_tags_table',1),(25,'2021_07_15_092127_create_blogs_table',1),(26,'2021_07_15_094035_create_workdays_table',1),(27,'2021_07_24_043550_create_galleries_table',1),(28,'2021_08_15_044103_create_ratings_table',1),(29,'2021_08_15_045200_create_savings_table',1),(30,'2021_08_15_060135_create_reviews_table',1),(31,'2021_08_15_060834_create_partners_table',1),(32,'2021_08_15_084647_create_routes_organizators_table',1),(33,'2021_08_17_152056_create_phones_table',1),(34,'2021_08_17_152108_create_emails_table',1),(35,'2021_08_17_152126_create_socials_table',1),(36,'2021_08_17_152522_create_settings_table',1),(37,'2021_08_21_060723_create_route_place_table',1),(38,'2021_08_21_100702_create_place_event_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `news` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned NOT NULL,
  `author_id` bigint unsigned NOT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_ru` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_kz` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `news_category_id_foreign` (`category_id`),
  KEY `news_author_id_foreign` (`author_id`),
  CONSTRAINT `news_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categorynews` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (2,2,1,'Дворцы школьников и молодежи появятся в Шымкенте','Palaces of schoolchildren and youth will appear in Shymkent','Шымкентте оқушылар мен жастар сарайы ашылады','<p>Об&nbsp;этом на&nbsp;отчетной встрече сообщил глава города. По&nbsp;его словам, большой проблемой для города является охват детей дополнительным образованием.<br />\r\n⠀<br />\r\n&laquo;Всего 16 процентов учащихся школ города охвачены дополнительным образованием. Для решения проблем мы&nbsp;реконструируем бывший дворец Фосфорников и&nbsp;откроем его в&nbsp;качестве Дворца молодежи. Кроме того, мы&nbsp;планируем начать строительство нового современного Дворца школьников&raquo;.<br />\r\n⠀<br />\r\nВ&nbsp;результате, по&nbsp;прогнозам властей, до&nbsp;2025 года охват детей дополнительным образованием будет увеличен почти в&nbsp;3,5 раза&nbsp;&mdash; с&nbsp;нынешних 16% до&nbsp;55%.<br />\r\n⠀<br />\r\nТакже, по&nbsp;информации&nbsp;М. Айтенова, в&nbsp;этом году на&nbsp;оснащение школ направят около шести миллиардов тенге.<br />\r\n⠀<br />\r\n&laquo;Оборудовано всего 32 процента учебных кабинетов. Школы будут оснащены 259 специальными предметными кабинетами. Если в&nbsp;начале прошлого года на&nbsp;27 учеников Шымкента приходился один компьютер, то&nbsp;сейчас на&nbsp;четыре ученика приходится один компьютер. Эта работа будет продолжена в&nbsp;этом году&raquo;,&nbsp;&mdash; подчеркнул спикер.<br />\r\n⠀<br />\r\nВо&nbsp;дворах 28 школ будут построены спортивные площадки. В&nbsp;прошлом году для безопасности детей в&nbsp;зданиях 36-ти школ установили туалеты, в&nbsp;Шымкенте этот вопрос полностью решен. В&nbsp;течение года во&nbsp;всех организациях образования появятся камеры видеонаблюдения современного образца, а&nbsp;также турникеты, которые будут подключены к&nbsp;системе полиции.</p>','<p>This was announced by the head of the city at the reporting meeting. According to him, a big problem for the city is the coverage of children with additional education.&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&quot;Only 16 percent of students in the city&#39;s schools are covered by additional education. To solve the problems, we will reconstruct the former Phosphor Palace and open it as a Youth Palace. In addition, we plan to start construction of a new modern Palace of Schoolchildren.&quot; As a result, according to the forecasts of the authorities, by 2025, the coverage of children with additional education will be increased by almost 3.5 times &mdash; from the current 16% to 55%.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;Also, according to M. Aitenov, this year about six billion tenge will be allocated for equipping schools. &quot;Only 32 percent of classrooms are equipped. Schools will be equipped with 259 special subject rooms. If at the beginning of last year there was one computer for 27 students of Shymkent, now there is one computer for four students. This work will be continued this year, &quot; the speaker stressed. ⠀</p>','<p>Бұл туралы есеп беру кездесуінде қала басшысы хабарлады. Оның айтуынша, қала үшін балаларды қосымша біліммен қамту үлкен проблема болып табылады.&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&quot;Қала мектептерінің оқушыларының 16 пайызы ғана қосымша біліммен қамтылған. Мәселелерді шешу үшін біз бұрынғы Фосфоршылар сарайын қайта құрып, оны Жастар сарайы ретінде ашамыз. Сонымен қатар, біз жаңа заманауи Оқушылар сарайының құрылысын бастауды жоспарлап отырмыз&quot;. ⠀&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Нәтижесінде, биліктің болжамы бойынша 2025 жылға дейін балаларды қосымша біліммен қамту 3,5 есеге жуық &mdash; Қазіргі 16% - дан 55% - ға дейін ұлғайтылады. Сондай-ақ, М.Әйтеновтың айтуынша, биыл мектептерді жабдықтауға алты миллиард теңге бөлінеді. ⠀&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&quot;Оқу кабинеттерінің 32 пайызы ғана жабдықталған. Мектептер 259 арнайы пәндік кабинеттермен жабдықталады. Егер өткен жылдың басында Шымкенттің 27 оқушысына бір компьютер келсе, қазір төрт оқушыға бір компьютерден келеді. Бұл жұмыс биыл да жалғасатын болады&quot;, - деп атап өтті спикер.</p>','dvorcy-shkolnikov-i-molodezhi-poyavyatsya-v-shymkente','3dscTlxQhW.png',1,'2021-08-22 02:54:52','2021-08-22 02:54:52'),(3,3,5,'Huawei официально начала продавать подержанные смартфоны с новыми аккумуляторами, они пользуются огромным спросом в Китае','Huawei has officially started selling used smartphones with new batteries, they are in great demand in China','Huawei ресми түрде жаңа батареялары бар пайдаланылған смартфондарды сата бастады, олар Қытайда үлкен сұранысқа ие','<p>Уже понятно, что эта стратегия оправдала себя</p>\r\n\r\n<p>Китайский технологический гигант Huawei официально начал продавать сертифицированные бывшие в употреблении телефоны в своём китайском интернет магазине.</p>\r\n\r\n<p>Новое предложение Huawei позволяет приобрести со скидкой различные смартфоны, которые сертифицированы самой компанией, чтобы гарантировать их качество. Считается, что этого шага выиграют обе стороны: пользователи получат телефоны по более привлекательным ценам, а производитель сможет немного улучшить ситуацию с наличием смартфонов в магазинах на фоне их глобальной нехватки.</p>\r\n\r\n<p>Интересно, что не так давно мы сообщали о подорожании бывших в употреблении телефонов Huawei с поддержкой 5G после того, как компания анонсировала флагманскую серию P50, которая поддерживает только сети 4G.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt=\"\" src=\"http://backend.visit-shymkent/images/Huawei-Mate-30-Pro_large_large_1629622685.jpg\" style=\"height:397px; width:780px\" /></p>','<p>It is already clear that this strategy has paid off</p>\r\n\r\n<p>Chinese technology giant Huawei has officially started selling certified used phones in its Chinese online store.</p>\r\n\r\n<p>Huawei&#39;s new offer allows you to purchase various smartphones at a discount, which are certified by the company itself to guarantee their quality. It is believed that both sides will benefit from this step: users will receive phones at more attractive prices, and the manufacturer will be able to slightly improve the situation with the availability of smartphones in stores against the background of their global shortage.</p>\r\n\r\n<p>Interestingly, not so long ago we reported about the rise in price of used Huawei phones with 5G support after the company announced the flagship P50 series, which supports only 4G networks.</p>\r\n\r\n<p><img alt=\"\" src=\"http://backend.visit-shymkent/images/Huawei-Mate-30-Pro_large_large_1629622685.jpg\" style=\"height:397px; width:780px\" /></p>','<p>Бұл стратегия өзін ақтағаны анық</p>\r\n\r\n<p>Қытайдың технологиялық алыбы Huawei ресми түрде өзінің қытай интернет-дүкенінде пайдаланылған сертификатталған телефондарды сата бастады.</p>\r\n\r\n<p>Huawei-дің жаңа ұсынысы олардың сапасына кепілдік беру үшін компанияның өзі сертификаттаған түрлі смартфондарды жеңілдікпен сатып алуға мүмкіндік береді. Бұл қадамның екі жағында да пайда болады деп саналады: пайдаланушылар телефондарды неғұрлым тартымды бағамен алады, ал өндіруші дүкендерде смартфондардың Ғаламдық жетіспеушілігі жағдайында жағдайды сәл жақсарта алады.</p>\r\n\r\n<p>Бір қызығы, жақында біз Huawei-дің 5G қолдайтын телефондарының қымбаттағаны туралы компания тек 50g желілерін қолдайтын P4 флагмандық сериясын жариялағаннан кейін хабарладық.</p>\r\n\r\n<p><img alt=\"\" src=\"http://backend.visit-shymkent/images/Huawei-Mate-30-Pro_large_large_1629622685.jpg\" style=\"height:397px; width:780px\" /></p>','huawei-oficialno-nachala-prodavat-poderzhannye-smartfony-s-novymi-akkumulyatorami-oni-polzuyutsya-ogromnym-sprosom-v-kitae','MmYnULh2jA.jpg',1,'2021-08-22 02:59:30','2021-08-22 02:59:30');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `organizators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizators` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_ru` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_kz` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `education_ru` text COLLATE utf8mb4_unicode_ci,
  `education_kz` text COLLATE utf8mb4_unicode_ci,
  `education_en` text COLLATE utf8mb4_unicode_ci,
  `languages` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alias` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `eventum` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` json DEFAULT NULL,
  `social_networks` json DEFAULT NULL,
  `sites` json DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `organizators_user_id_foreign` (`user_id`),
  KEY `organizators_role_id_foreign` (`role_id`),
  CONSTRAINT `organizators_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `organizators_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `organizators` WRITE;
/*!40000 ALTER TABLE `organizators` DISABLE KEYS */;
INSERT INTO `organizators` VALUES (2,8,5,'SHYMKENT TOUR','SHYMKENT TOUR','SHYMKENT TOUR','<p>SHYMKENT TOUR - ОКАЗЫВАЕМ РЯД ТУРИСТИЧЕСКИХ УСЛУГ!</p>\r\n\r\n<p>О компании</p>\r\n\r\n<p>Компания Shymtour имеет многолетний опыт по организации туров в ЮКО, СНГ и по всему миру.</p>\r\n\r\n<ul>\r\n	<li>Экскурсионные туры</li>\r\n	<li>Организация VIP-туров и оригинальных программ по индивидуальным заявкам</li>\r\n	<li>Хаял отели</li>\r\n</ul>\r\n\r\n<p>Предоставление отдельных видов услуг</p>\r\n\r\n<ul>\r\n	<li>Бронирование гостиниц</li>\r\n	<li>Заказ авиа и Ж/Д-билетов</li>\r\n	<li>Оформление виз</li>\r\n</ul>','<p>SHYMKENT TOUR - БІЗ БІРҚАТАР ТУРИСТІК ҚЫЗМЕТТЕРДІ ҰСЫНАМЫЗ!</p>\r\n\r\n<p>Компания туралы</p>\r\n\r\n<p>Shymtour компаниясының ОҚО, ТМД және бүкіл әлем бойынша турларды ұйымдастыруда көп жылдық тәжірибесі бар.</p>\r\n\r\n<ul>\r\n	<li>Экскурсиялық турлар</li>\r\n	<li>Жеке өтінімдер бойынша VIP-турлар мен бірегей бағдарламаларды ұйымдастыру</li>\r\n	<li>Хаял қонақ үйлер</li>\r\n</ul>\r\n\r\n<p>Жекелеген қызмет түрлерін ұсыну</p>\r\n\r\n<ul>\r\n	<li>Қонақ үй брондау</li>\r\n	<li>Авиа және т/ж билеттеріне тапсырыс беру</li>\r\n	<li>Визаларды рәсімдеу</li>\r\n</ul>','<p>SHYMKENT TOUR-WE PROVIDE A NUMBER OF TOURIST SERVICES!</p>\r\n\r\n<p>About the company</p>\r\n\r\n<p>The company Shimtour has many years of experience in organizing tours in South Kazakhstan, the CIS and around the world.</p>\r\n\r\n<ul>\r\n	<li>Sightseeing tours</li>\r\n	<li>Organization of VIP tours and original programs on individual requests</li>\r\n	<li>Khayal hotels</li>\r\n</ul>\r\n\r\n<p>Provision of certain types of services</p>\r\n\r\n<ul>\r\n	<li>Hotel reservations</li>\r\n	<li>Booking of air and Railway tickets</li>\r\n	<li>Visa processing</li>\r\n</ul>',NULL,NULL,NULL,NULL,'8abHaDIjrj.jpg','shymkent-tour',NULL,'[\"+7 7252 37 10 37\", \"+7 771 019 83 35\"]','[\"info@usadbaladushki.kz\"]','[\"usadbaladushki.kz\"]','мкр. Нурсат, пр. Н. Назарбаева 6',1,'2021-08-22 02:04:55','2021-08-22 02:04:55'),(3,7,4,'Индиана Джонс','Индиана Джонс','Indiana Jones','<p><strong>Гид экскурсовод</strong></p>\r\n\r\n<p>- Сертификат по ораторскому исскуству.</p>\r\n\r\n<p>Туристские маршруты</p>\r\n\r\n<p>Сертифицированный гид &ndash; экскурсовод города Шымкент и туркестанской области.</p>\r\n\r\n<p>Сертификаты</p>\r\n\r\n<p>- Сертификат по ораторскому исскуству.</p>','<p><strong>Гид Нұсқаулық</strong><br />\r\n- - Шешендік өнер бойынша Сертификат.<br />\r\nТуристік бағыттар<br />\r\nШымкент қаласы мен Түркістан облысының сертификатталған гид &ndash; экскурсоводы.<br />\r\nСертификаттар<br />\r\n- - Шешендік өнер бойынша Сертификат.</p>','<p><strong>Tour guide</strong><br />\r\n- - Certificate in Public Speaking.<br />\r\nTourist routes<br />\r\nCertified tour guide of the city of Shymkent and the Turkestan region.<br />\r\nCertificates<br />\r\n- - Certificate in Public Speaking.</p>','<p>Персональная информация<br />\r\nВысшее образование АИТБ, ШФ АУНО. Шымкент, историк-географ, specialist in practical psychology.</p>\r\n\r\n<p>&nbsp;</p>','<p>Жеке ақпарат<br />\r\nЖоғары білім АИТБ, ШФ АУНО. Шымкент, тарихшы-географ, specialist in practical psychology.</p>','<p>Personal information<br />\r\nHigher education of AITB, SHF AUNO. Shymkent, historian-geographer, specialist in practical psychology.</p>','[\"\\u049a\\u0430\\u0437\\u0430\\u049b \\u0422\\u0456\\u043b\\u0456\",\"\\u0420\\u0443\\u0441\\u0441\\u043a\\u0438\\u0439 \\u042f\\u0437\\u044b\\u043a\",\"English Language\"]','p0JmnpavM0.jpg','indiana-dzhons',NULL,NULL,NULL,NULL,NULL,1,'2021-08-22 02:10:33','2021-08-22 02:10:33'),(4,12,4,'GUIDE','GUIDE','GUIDE','<p>GUIDE</p>','<p>GUIDE</p>','<p>GUIDE</p>','<p>GUIDE</p>','<p>GUIDE</p>','<p>GUIDE</p>',NULL,'qv8JuHcqFf.jpg','guide','GUIDE',NULL,NULL,NULL,NULL,1,'2021-08-29 07:51:19','2021-08-29 07:51:20');
/*!40000 ALTER TABLE `organizators` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partners` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alias` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `partners` WRITE;
/*!40000 ALTER TABLE `partners` DISABLE KEYS */;
/*!40000 ALTER TABLE `partners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `phones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `phones` WRITE;
/*!40000 ALTER TABLE `phones` DISABLE KEYS */;
/*!40000 ALTER TABLE `phones` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `place_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `place_event` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `place_id` bigint unsigned DEFAULT NULL,
  `event_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `place_event_place_id_foreign` (`place_id`),
  KEY `place_event_event_id_foreign` (`event_id`),
  CONSTRAINT `place_event_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `place_event_place_id_foreign` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `place_event` WRITE;
/*!40000 ALTER TABLE `place_event` DISABLE KEYS */;
INSERT INTO `place_event` VALUES (6,8,4,'2021-08-22 01:09:19','2021-08-22 01:09:19'),(7,8,5,'2021-08-22 01:18:04','2021-08-22 01:18:04'),(8,5,7,'2021-08-29 00:42:47','2021-08-29 00:42:47');
/*!40000 ALTER TABLE `place_event` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `place_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `place_type` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `place_type` WRITE;
/*!40000 ALTER TABLE `place_type` DISABLE KEYS */;
INSERT INTO `place_type` VALUES (1,'Место','Орын','Place','2021-08-21 04:09:03','2021-08-21 04:09:03'),(2,'Точка маршрута','Бағыт нүктесі','Point of route','2021-08-21 04:09:03','2021-08-21 04:09:03');
/*!40000 ALTER TABLE `place_type` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `places` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type_id` bigint unsigned NOT NULL,
  `organizator_id` bigint unsigned DEFAULT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_ru` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_kz` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `eventum` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` json DEFAULT NULL,
  `social_networks` json DEFAULT NULL,
  `sites` json DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_link` longtext COLLATE utf8mb4_unicode_ci,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_ru` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_kz` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `audio_ru` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `audio_kz` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `audio_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `places_type_id_foreign` (`type_id`),
  KEY `places_organizator_id_foreign` (`organizator_id`),
  CONSTRAINT `places_organizator_id_foreign` FOREIGN KEY (`organizator_id`) REFERENCES `organizators` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `places_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `place_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `places` WRITE;
/*!40000 ALTER TABLE `places` DISABLE KEYS */;
INSERT INTO `places` VALUES (5,1,NULL,'Парк Наурыз','Наурыз Саябағы','Nauryz Park','<p>Парк аттракционов в 8 га в жилом массиве &laquo;Сайрам&raquo; был построен 26 лет назад, сейчас можно сказать что он пережил второе рождение. 4 июля 2017 года отремонтированный парк открылся после реконструкции, в открытии парка приняли участие акимы Южно-Казахстнаской области и города Шымкент - Жансеит Туймебаев и Габидулла Абдрахимов. Парк преобразился, здесь обновили фасад, укрепили берега искусственного водоема, установили удобные скамейки. Решен вопрос полива зеленых насаждений &ndash; эту задачу будут решать посредством скважины. Ремонт парка обошелся в 180 млн. тенге. У входа в парк появилась мраморная плитка, а арку отделали травертином. Безусловно, это место вновь станет одним из излюбленных мест жителей жилого массива &quot;Сайрам&quot;</p>','<p>Сайрам тұрғын алабында 8 га аттракциондар паркі 26 жыл бұрын салынған, қазір ол қайта туды деп айтуға болады. 2017 жылдың 4 шілдесінде жөнделген саябақ реконструкциядан кейін ашылды, парктің ашылуына Оңтүстік Қазақстан облысының және Шымкент қаласының әкімдері-Жансейіт Түймебаев пен Ғабидолла Әбдірахымов қатысты. Саябақ көркейіп, қасбеті жаңартылды, жасанды су қоймасының жағалары нығайтылды, ыңғайлы орындықтар орнатылды. Жасыл желектерді суару мәселесі шешілді-бұл міндет ұңғыма арқылы шешілетін болады. Саябақты жөндеуге 180 млн. теңге жұмсалды. Саябаққа кіре берісте мәрмәр плиткалар пайда болды, ал арка травертинмен аяқталды. Әрине, бұл жер &quot;Сайрам&quot;тұрғын алабы тұрғындарының сүйікті орындарының біріне айналады</p>','<p>The amusement park of 8 hectares in the residential area &quot;Sairam&quot; was built 26 years ago, now we can say that it has experienced a rebirth. On July 4, 2017, the renovated park was opened after reconstruction, akims of the South Kazakhstan region and the city of Shymkent-Zhanseit Tuimebayev and Gabidulla Abdrakhimov took part in the opening of the park. The park has been transformed, the facade has been updated here, the banks of an artificial reservoir have been strengthened, comfortable benches have been installed. The issue of irrigation of green spaces has been resolved &ndash; this task will be solved by means of a well. The repair of the park cost 180 million tenge. Marble tiles appeared at the entrance to the park, and the arch was decorated with travertine. Of course, this place will again become one of the favorite places of residents of the residential area &quot;Sairam&quot;</p>','park-nauryz',NULL,NULL,NULL,NULL,'пр-т. Байдибек би 25','[{\"lat\":42.33337223589656,\"lng\":69.65606689453126}]',NULL,'if71hqeU9D.jpg',NULL,NULL,NULL,NULL,NULL,NULL,1,'2021-08-22 00:27:13','2021-08-22 00:38:12'),(6,1,NULL,'ТОО «Magnum Cash&Carry»','ТОО «Magnum Cash&Carry»','ТОО «Magnum Cash&Carry»','<p>Крупнейшая торгово-розничная сеть Казахстана, входит в десятку крупнейших частных компаний страны. Основной деятельностью является реализация товаров широкого потребления. Сети принадлежит 77 торговых комплексов разного формата ( гипермаркеты, супермаркеты и магазины &laquo;Magnum-express&raquo; малого формата) в девяти городах Казахстана: Алматы, Нур-Султане, Шымкенте, Караганде, Талдыкоргане, Таразе, Петропавловске, Кызылорде, Каскелене. Общее количество покупателей торгово-розничной сети &laquo;Magnum Cash &amp; Carry&raquo; превышает 300 000 человек в день. Штат сотрудников насчитывает более 11000 человек.</p>','<p>Қазақстанның ірі сауда-бөлшек сауда желісі еліміздегі ең ірі жеке компаниялардың ондығына кіреді. Негізгі қызмет-тұтыну тауарларын сату. Желі Қазақстанның тоғыз қаласында: Алматы, Нұр-сұлтан, Шымкент, Қарағанды, Талдықорған, Тараз, Петропавл, Қызылорда, Қаскелең қалаларында түрлі форматтағы ( шағын форматтағы гипермаркеттер, Супермаркеттер және &quot;Magnum-express&quot; дүкендері) 77 сауда кешеніне тиесілі. &quot;Magnum Cash &amp; Carry&quot; сауда-бөлшек сауда желісін сатып алушылардың жалпы саны күніне 300 000 адамнан асады. Қызметкерлер саны 11000 адамнан асады.</p>','<p>The largest retail and retail network in Kazakhstan, is one of the ten largest private companies in the country. The main activity is the sale of consumer goods. The chain owns 77 shopping complexes of various formats ( hypermarkets, supermarkets and small-format Magnum-express stores) in nine cities of Kazakhstan: Almaty, Nur-Sultan, Shymkent, Karaganda, Taldykorgan, Taraz, Petropavlovsk, Kyzylorda, Kaskelen. The total number of customers of the Magnum Cash &amp; Carry retail chain exceeds 300,000 people per day. The staff consists of more than 11,000 people.</p>','too-magnum-cash-carry',NULL,NULL,NULL,NULL,'ул. Айтике би, уг. ул. Володарского, здание ТРЦ «Жамалбек-Кажы»,г.ШЫМКЕНТ, район Абайский, микрорайон Енбекшинский, Сайрамская 225/2,ШФ6 (MAGNUM ЭКСПРЕСС) г.ШЫМКЕНТ, Байтурсынова, 81','[{\"lat\":42.33986909612021,\"lng\":69.56542968750001},{\"lat\":42.33986909612021,\"lng\":69.68627929687501},{\"lat\":42.33986909612021,\"lng\":69.68627929687501},{\"lat\":42.33986909612021,\"lng\":69.56542968750001}]',NULL,'Hd9ZaGrkIA.jpg',NULL,NULL,NULL,NULL,NULL,NULL,1,'2021-08-22 00:53:20','2021-08-22 00:53:33'),(7,1,NULL,'Перевернутый дом','Төңкерілген үй','The upside-down house','<p>Невероятные впечатления взрослым и детям любого возраста принесет посещение необычайного сооружения &laquo;Перевернутый дом&raquo;. Это самый настоящий дом со спальней, кухней, гостиной и уборной. Вся прелесть места состоит в том, что мебель, бытовая утварь и даже накрытый дастархан размещены вверх ногами. Прогуляться по этому дому можно только по потолку, а дотронуться до аппетитных фруктов смогут исключительно высокие люди или дети, поднятые на руки. В невероятном доме посетители могут свободно гулять и делать удивительные фотографии в самом необычайном ракурсе.</p>','<p>Ересектер мен кез-келген жастағы балаларға керемет әсер &quot;төңкерілген үй&quot;ерекше құрылымына барады. Бұл жатын бөлме, ас үй, қонақ бөлме және дәретхана бар нағыз үй. Орынның барлық сұлулығы-жиһаз, тұрмыстық заттар, тіпті жабық дастархан төңкеріліп орналастырылған. Сіз бұл үйді тек төбеде серуендей аласыз, ал қолыңызға көтерілген өте ұзын адамдар немесе балалар тәбетті жемістерге қол тигізе алады. Керемет үйде келушілер еркін серуендеп, таңғажайып фотосуреттер түсіре алады.</p>','<p>An incredible experience for adults and children of any age will bring a visit to the extraordinary structure &quot;Inverted House&quot;. This is a real house with a bedroom, a kitchen, a living room and a toilet. The beauty of the place is that the furniture, household utensils and even a covered dastarkhan are placed upside down. You can walk around this house only on the ceiling, and only tall people or children raised in their arms will be able to touch delicious fruits. In the incredible house, visitors can freely walk and take amazing photos from the most extraordinary angle.</p>','perevernutyy-dom',NULL,NULL,'[\"https://www.instagram.com/dom_shymkent/\"]',NULL,'​Республики проспект, 6а/2','[{\"lat\":42.32667162499381,\"lng\":69.57847595214845}]',NULL,'5l3GaWFDQx.jpg',NULL,NULL,NULL,NULL,NULL,NULL,1,'2021-08-22 00:58:23','2021-08-22 00:58:23'),(8,1,NULL,'Шымкентский государственный зоологический парк','Шымкент мемлекеттік зоологиялық паркі','Shymkent State Zoological Park','<p>Шымкентский государственный зоопарк был организован в 1979 году и является важной достопримечательностью города и всего региона. Официальным днем рождением зоопарка считается 29 апреля 1980 года. Общая площадь составляет 54 га. На 34 га экспозиционной площади разбит прекрасный парк, в котором высажены около 3,5 тысяч декоративных и 50 видов фруктовых деревьев, 10 видов чайно-гибридных кустов роз. Первая коллекция зоопарка насчитывала 75 видов и 350 единиц животных и птиц. Здесь регулярно размножаются олени, архары, пони, тигровые питоны, львы и другие животные. Сегодня &laquo;Шымкентский государственный зоопарк&raquo; - своеобразный и уникальный уголок живой природы. С июля 2010 года входят в состав Евроазиатской Региональной Ассоциации Зоопарков и Аквариумов. Одной из главных миссий зоопарка является сохранение и разведение редких в природе животных, занесенных в Красную книгу Казахстана. Также, сотрудники зоопарка проводят для посетителей экскурсии, радио-лекции, беседы, во время которых биологи и ведущие специалисты делятся своими знаниями о животных. Зоопарк &ndash; одно из самых популярных мест отдыха горожан и гостей Шымкента. Ежегодно зоопарк посещают более 300 000 человек.</p>','<p>Шымкент мемлекеттік хайуанаттар бағы 1979 жылы ұйымдастырылған және қаланың және бүкіл өңірдің маңызды көрікті жері болып табылады. Хайуанаттар бағының ресми туған күні - 1980 жылғы 29 сәуір. Жалпы ауданы 54 га. 34 га экспозиция алаңында әдемі саябақ бар, онда 3,5 мыңға жуық сәндік және 50 жеміс ағаштары, шай-гибридті раушан бұталарының 10 түрі отырғызылған. Хайуанаттар бағының алғашқы коллекциясында 75 түрі және жануарлар мен құстардың 350 бірлігі болды. Мұнда бұғы, арқар, пони, жолбарыс питондары, арыстандар және басқа да жануарлар үнемі өсіріледі. Бүгінгі таңда &quot;Шымкент мемлекеттік хайуанаттар бағы&quot; - жабайы табиғаттың ерекше және бірегей бұрышы. 2010 жылдың шілдесінен бастап олар хайуанаттар мен аквариумдардың Еуразиялық аймақтық қауымдастығының құрамына кіреді. Хайуанаттар бағының басты миссияларының бірі Қазақстанның Қызыл кітабына енген, табиғатта сирек кездесетін жануарларды сақтау және өсіру болып табылады. Сондай-ақ, хайуанаттар бағының қызметкерлері келушілер үшін экскурсиялар, радио дәрістер, әңгімелер өткізеді, оның барысында биологтар мен жетекші мамандар жануарлар туралы білімдерімен бөліседі. Хайуанаттар бағы-Шымкент қаласының тұрғындары мен қонақтарының ең танымал демалыс орындарының бірі. Жыл сайын хайуанаттар бағына 300 000-нан астам адам келеді.</p>','<p>The Shymkent State Zoo was organized in 1979 and is an important attraction of the city and the entire region. The official birthday of the zoo is considered to be April 29, 1980. The total area is 54 hectares. There is a beautiful park on 34 hectares of the exhibition area, in which about 3.5 thousand decorative and 50 types of fruit trees, 10 types of tea-hybrid rose bushes are planted. The first collection of the zoo consisted of 75 species and 350 units of animals and birds. Deer, argali, ponies, tiger pythons, lions and other animals regularly breed here. Today, the Shymkent State Zoo is a peculiar and unique corner of wildlife. Since July 2010, they have been part of the Eurasian Regional Association of Zoos and Aquariums. One of the main missions of the zoo is the conservation and breeding of rare animals listed in the Red Book of Kazakhstan. Also, the zoo staff conducts excursions, radio lectures, conversations for visitors, during which biologists and leading specialists share their knowledge about animals. The zoo is one of the most popular recreation places for residents and guests of Shymkent. More than 300,000 people visit the zoo every year.</p>','shymkentskiy-gosudarstvennyy-zoologicheskiy-park',NULL,'[\"+7 7252 47-60-30\"]',NULL,NULL,'проспект Байдибек би 113/1','[{\"lat\":42.33905705046833,\"lng\":69.5863723754883}]','300-600 тнг','ByGm34DkYS.jpg',NULL,NULL,NULL,NULL,NULL,NULL,1,'2021-08-22 01:09:19','2021-08-22 01:12:20'),(9,2,NULL,'Ресторан национальной казахской кухни «Sandyq»','\"Sandyq\" Қазақ ұлттық тағамдарының мейрамханасы','Restaurant of national Kazakh cuisine \"Sandyq\"','<p>Особые условия жизни казахского народа диктовали определенные требования к культуре приготовления еды и его пищевой ценности. Поэтому на протяжении нескольких месяцев над созданием гармонии вкуса блюд и их эстетики трудились самые талантливые повара и ученые, полностью адаптировавшие их к современным условиям и вкусовым предпочтениям.</p>','<p>Қазақ халқының өмір сүру жағдайы тағам дайындау мәдениеті мен оның тағамдық құндылығына белгілі бір талаптар қойды. Сондықтан, бірнеше ай бойы тағамдардың дәмі мен олардың эстетикасының үйлесімін жасау үшін ең талантты аспаздар мен ғалымдар жұмыс істеді, оларды заманауи жағдайлар мен талғамға сай бейімдеді.</p>','<p>The special living conditions of the Kazakh people dictated certain requirements for the culture of cooking and its nutritional value. Therefore, for several months, the most talented chefs and scientists have been working to create a harmony of the taste of dishes and their aesthetics, fully adapting them to modern conditions and taste preferences.</p>','restoran-nacionalnoy-kazahskoy-kuhni-sandyq',NULL,'[\"+7‒777‒919‒11‒22\"]',NULL,NULL,'​​проспект Тауке Хана, 170/4','[{\"lat\":42.32037646315947,\"lng\":69.59083557128908}]',NULL,'7t9ndAluua.jpg',NULL,NULL,NULL,NULL,NULL,NULL,1,'2021-08-22 01:30:50','2021-08-22 01:30:50'),(10,2,NULL,'«Азрет-Султан»','\"Әзірет Сұлтан\"','\"Azret-Sultan\"','<p><strong>Туркестан &mdash; один из древнейших городов Казахстана. Этот город окружен бесценными памятниками прошлого и является центром паломнического и исторического туризма.</strong></p>\r\n\r\n<p>Именно здесь находится Государственный историко-культурный музей-заповедник &laquo;Азрет-Султан&raquo; &mdash; это целый комплекс археологических и архитектурных памятников, основанный в 1978 году на базе музея архитектурного комплекса Ходжи Ахмеда Ясави.</p>','<p><strong>Түркістан-Қазақстанның ежелгі қалаларының бірі. Бұл қала өткеннің баға жетпес ескерткіштерімен қоршалған және қажылық пен тарихи туризмнің орталығы болып табылады.</strong></p>\r\n\r\n<p>Дәл осы жерде &quot;Әзірет Сұлтан&quot; мемлекеттік тарихи-мәдени қорық-мұражайы орналасқан, ол 1978 жылы Қожа Ахмет Ясауи сәулет кешені мұражайының негізінде қаланған археологиялық және сәулет ескерткіштерінің тұтас кешені.</p>','<p><strong>Turkestan is one of the oldest cities in Kazakhstan. This city is surrounded by priceless monuments of the past and is a center of pilgrimage and historical tourism.</strong></p>\r\n\r\n<p>It is here that the State Historical and Cultural Museum-Reserve &quot;Azret-Sultan&quot; is located &mdash; it is a whole complex of archaeological and architectural monuments, founded in 1978 on the basis of the museum of the architectural complex of Khoja Ahmed Yasawi.</p>','azret-sultan',NULL,NULL,NULL,NULL,NULL,'[{\"lat\":43.36352833593019,\"lng\":68.29650878906251}]',NULL,'ptupANI1zv.jpg',NULL,NULL,NULL,NULL,NULL,NULL,1,'2021-08-22 01:34:50','2021-08-22 01:34:50'),(11,1,NULL,'Ресторан «Grand Praga» с дегустацией вин Chateau Silk Alley','Chateau Silk Alley шараптарынан дәм тататын \"Grand Praga\" мейрамханасы','Grand Praga restaurant with wine tasting Chateau Silk Alley','<p>Меню на английском, DJ, настольные игры, своя пекарня, бильярд, бранчи, живая музыка, бесплатная парковка, барная стойка, винная карта, танцпол, закрытие под банкет Средний счёт 5000&ndash;10000 тнг</p>','<p>Ағылшын тіліндегі мәзір, DJ, үстел ойындары, өз наубайханасы, бильярд, таңғы ас, жанды музыка, тегін тұрақ, бар, шарап картасы, би алаңы, банкетке жабу орташа есеп 5000-10000 тнг</p>','<p>English menu, DJ, board games, own bakery, billiards, brunches, live music, free parking, bar counter, wine list, dance floor, closing for a banquet Average bill 5000-10000 tng</p>','restoran-grand-praga-s-degustaciey-vin-chateau-silk-alley',NULL,'[\"+7 702 011 11 20\"]',NULL,NULL,'Казиева 80','[{\"lat\":42.325656318414886,\"lng\":69.58946228027345}]',NULL,'SgFe9XQiU2.png',NULL,NULL,NULL,NULL,NULL,NULL,1,'2021-08-22 01:38:04','2021-08-22 01:38:04'),(12,2,NULL,'Международный фестиваль воздухоплавания «Ashyq Aspan»','\"Ashyq Aspan\" халықаралық Әуеде жүзу фестивалі','International Aeronautics Festival \"Ashyq Aspan\"','<p>&laquo;ASHYQ ASPAN&raquo; - это уникальный фестиваль на территории РК. Это некий микс таких западных фестивалей как - Coachella, Burning man, но со своей изюминкой - воздушными Шарами!</p>','<p>&quot;ASHYQ ASPAN&quot; - бұл ҚР аумағындағы бірегей фестиваль. Бұл - Coachella, Burning man сияқты батыстық фестивальдердің белгілі бір қоспасы, бірақ оның ерекшелігі - шарлар!</p>','<p>&quot;ASHYQ ASPAN&quot; is a unique festival on the territory of the Republic of Kazakhstan. This is a kind of mix of such Western festivals as-Coachella, Burning man, but with its own highlight-balloons!</p>','mezhdunarodnyy-festival-vozduhoplavaniya-ashyq-aspan',NULL,NULL,NULL,NULL,NULL,'[{\"lat\":42.313522140011045,\"lng\":69.7291946411133},{\"lat\":42.318853344756434,\"lng\":69.61212158203126}]',NULL,'QOex1AP7YD.jpg',NULL,NULL,NULL,NULL,NULL,NULL,1,'2021-08-22 01:52:39','2021-08-22 01:52:39');
/*!40000 ALTER TABLE `places` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ratings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `place_id` bigint unsigned DEFAULT NULL,
  `event_id` bigint unsigned DEFAULT NULL,
  `route_id` bigint unsigned DEFAULT NULL,
  `blog_id` bigint unsigned DEFAULT NULL,
  `news_id` bigint unsigned DEFAULT NULL,
  `shop_id` bigint unsigned DEFAULT NULL,
  `organizator_id` bigint unsigned DEFAULT NULL,
  `souvenir_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ratings_place_id_foreign` (`place_id`),
  KEY `ratings_event_id_foreign` (`event_id`),
  KEY `ratings_route_id_foreign` (`route_id`),
  KEY `ratings_blog_id_foreign` (`blog_id`),
  KEY `ratings_news_id_foreign` (`news_id`),
  KEY `ratings_shop_id_foreign` (`shop_id`),
  KEY `ratings_organizator_id_foreign` (`organizator_id`),
  KEY `ratings_souvenir_id_foreign` (`souvenir_id`),
  CONSTRAINT `ratings_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ratings_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ratings_news_id_foreign` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ratings_organizator_id_foreign` FOREIGN KEY (`organizator_id`) REFERENCES `organizators` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ratings_place_id_foreign` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ratings_route_id_foreign` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ratings_shop_id_foreign` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ratings_souvenir_id_foreign` FOREIGN KEY (`souvenir_id`) REFERENCES `souvenirs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ratings` WRITE;
/*!40000 ALTER TABLE `ratings` DISABLE KEYS */;
INSERT INTO `ratings` VALUES (1,'TPADVISOR','4.3',7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-08-22 00:59:26','2021-08-22 00:59:26'),(2,'ВИЗИТ-ШЫМКЕНТ','4',NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,'2021-08-29 07:33:25','2021-08-29 07:33:25'),(3,'TPADVISOR','3',NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,'2021-08-29 07:34:01','2021-08-29 07:34:01'),(4,'TripAdvisor','5',11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-08-29 21:34:43','2021-08-29 21:34:43'),(5,'Visit-Shymkent','4',11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-08-29 21:34:58','2021-08-29 21:34:58'),(6,'2GIS','4',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,'2021-08-30 00:05:28','2021-08-30 00:05:28'),(7,'TRIPADVISOR','5',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,'2021-08-30 00:05:53','2021-08-30 00:05:53'),(8,'VisitShymkent','5',NULL,NULL,NULL,NULL,NULL,5,NULL,NULL,'2021-08-30 00:13:00','2021-08-30 00:13:00'),(9,'2Gis','4',NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,'2021-08-30 00:59:44','2021-08-30 00:59:44'),(10,'Visit-Shymkent','4',NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,'2021-08-30 01:00:47','2021-08-30 01:00:47'),(11,'234','4',NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,'2021-08-30 01:02:36','2021-08-30 01:02:36'),(12,'VISIT-SHYMKENT','4',NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,'2021-08-30 01:17:15','2021-08-30 01:17:15');
/*!40000 ALTER TABLE `ratings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `recoveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoveries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int NOT NULL,
  `expiration_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recoveries_user_id_foreign` (`user_id`),
  CONSTRAINT `recoveries_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `recoveries` WRITE;
/*!40000 ALTER TABLE `recoveries` DISABLE KEYS */;
/*!40000 ALTER TABLE `recoveries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `rating` text COLLATE utf8mb4_unicode_ci,
  `review` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `place_id` bigint unsigned DEFAULT NULL,
  `event_id` bigint unsigned DEFAULT NULL,
  `route_id` bigint unsigned DEFAULT NULL,
  `blog_id` bigint unsigned DEFAULT NULL,
  `news_id` bigint unsigned DEFAULT NULL,
  `shop_id` bigint unsigned DEFAULT NULL,
  `organizator_id` bigint unsigned DEFAULT NULL,
  `souvenir_id` bigint unsigned DEFAULT NULL,
  `status` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_user_id_foreign` (`user_id`),
  KEY `reviews_place_id_foreign` (`place_id`),
  KEY `reviews_event_id_foreign` (`event_id`),
  KEY `reviews_route_id_foreign` (`route_id`),
  KEY `reviews_blog_id_foreign` (`blog_id`),
  KEY `reviews_news_id_foreign` (`news_id`),
  KEY `reviews_shop_id_foreign` (`shop_id`),
  KEY `reviews_organizator_id_foreign` (`organizator_id`),
  KEY `reviews_souvenir_id_foreign` (`souvenir_id`),
  CONSTRAINT `reviews_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reviews_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reviews_news_id_foreign` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reviews_organizator_id_foreign` FOREIGN KEY (`organizator_id`) REFERENCES `organizators` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reviews_place_id_foreign` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reviews_route_id_foreign` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reviews_shop_id_foreign` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reviews_souvenir_id_foreign` FOREIGN KEY (`souvenir_id`) REFERENCES `souvenirs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
INSERT INTO `reviews` VALUES (41,6,NULL,'Новости крутые!',NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,1,'2021-08-23 10:38:15','2021-08-24 05:11:29'),(42,6,'5','Привет!',NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,1,'2021-08-23 10:43:04','2021-08-24 05:11:41'),(43,10,'4','Ну в целом, конечно не плохо, но можно было и лучше',NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,1,'2021-08-24 05:21:32','2021-08-24 05:22:04'),(44,10,'5','Круто! Где и когда будет?',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,1,'2021-08-27 08:36:36','2021-08-27 08:42:47'),(45,10,NULL,'Ура!',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,1,'2021-08-27 08:38:02','2021-08-27 08:42:57'),(48,6,'4','Хороший Гид оператор!',NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,1,'2021-08-30 01:30:50','2021-08-30 01:31:18'),(49,6,'4','Неплохой гид!',NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,1,'2021-08-30 01:39:20','2021-08-30 01:39:45'),(50,6,'5','Отличный тур агент!',NULL,NULL,NULL,NULL,NULL,NULL,4,NULL,1,'2021-08-30 01:43:16','2021-08-30 01:43:26');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Администратор','Администратор','Administrator','2021-08-21 04:09:03','2021-08-21 04:09:03'),(2,'Модератор','Модератор','Moderator','2021-08-21 04:09:03','2021-08-21 04:09:03'),(3,'Пользователь','Пользователь','User','2021-08-21 04:09:03','2021-08-21 04:09:03'),(4,'Гид','Гид','Guide','2021-08-21 04:09:03','2021-08-21 04:09:03'),(5,'Турагенство','Турагенство','Travel Agency','2021-08-21 04:09:03','2021-08-21 04:09:03'),(6,'Магазин','Дүкен','Shop','2021-08-21 04:09:03','2021-08-21 04:09:03'),(7,'Ремесленник','Қолөнерші','Handicraft','2021-08-21 04:09:03','2021-08-21 04:09:03'),(8,'Объект','Объект','Object','2021-08-21 04:09:03','2021-08-21 04:09:03');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `route_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alias` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `route_categories` WRITE;
/*!40000 ALTER TABLE `route_categories` DISABLE KEYS */;
INSERT INTO `route_categories` VALUES (2,'Обзорное место','Шолу орны','Overview place',NULL,'obzornoe-mesto',1,'2021-08-22 01:21:16','2021-08-22 01:21:16'),(3,'Отдых','Демалыс','Relax',NULL,'otdyh',1,'2021-08-22 01:21:51','2021-08-22 01:21:51'),(4,'Место питания','Тамақтану орны','A place of food',NULL,'mesto-pitaniya',1,'2021-08-22 01:22:29','2021-08-22 01:22:29');
/*!40000 ALTER TABLE `route_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `route_place`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route_place` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `route_id` bigint unsigned NOT NULL,
  `place_id` bigint unsigned NOT NULL,
  `number` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `route_place_route_id_foreign` (`route_id`),
  KEY `route_place_place_id_foreign` (`place_id`),
  CONSTRAINT `route_place_place_id_foreign` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `route_place_route_id_foreign` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `route_place` WRITE;
/*!40000 ALTER TABLE `route_place` DISABLE KEYS */;
INSERT INTO `route_place` VALUES (3,2,9,1,'2021-08-22 01:41:17','2021-08-22 01:41:17'),(4,2,10,2,'2021-08-22 01:41:17','2021-08-22 01:41:17'),(5,2,11,3,'2021-08-22 01:41:17','2021-08-22 01:41:17'),(6,3,5,1,'2021-08-22 01:59:49','2021-08-22 01:59:49'),(7,3,9,2,'2021-08-22 02:00:41','2021-08-22 02:00:41'),(8,3,12,3,'2021-08-22 02:00:54','2021-08-22 02:00:54');
/*!40000 ALTER TABLE `route_place` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `route_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alias` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `route_types` WRITE;
/*!40000 ALTER TABLE `route_types` DISABLE KEYS */;
INSERT INTO `route_types` VALUES (3,'На машине','Машинада','By car',NULL,'na-mashine',1,'2021-08-22 01:23:39','2021-08-22 01:23:39'),(4,'Пешком','Жаяу','On foot',NULL,'peshkom',1,'2021-08-22 01:24:06','2021-08-22 01:24:06'),(5,'На велосипеде','Велосипедпен','By bike',NULL,'na-velosipede',1,'2021-08-22 01:24:29','2021-08-22 01:24:29');
/*!40000 ALTER TABLE `route_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned NOT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_ru` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_kz` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alias` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `eventum` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `distance` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_link` longtext COLLATE utf8mb4_unicode_ci,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `routes_category_id_foreign` (`category_id`),
  CONSTRAINT `routes_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `route_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `routes` WRITE;
/*!40000 ALTER TABLE `routes` DISABLE KEYS */;
INSERT INTO `routes` VALUES (2,3,'БИЗНЕС-ТУР','БИЗНЕС-ТУР','BUSINESS TOUR','<p>08:00 - Сбор</p>\r\n\r\n<p>09:00-10:00 Завтрак в национальном ресторане казахской кухни &laquo;Sandyq&raquo;</p>\r\n\r\n<p>10:00-12:00 Вертолётная экскурсия &laquo;над Шымкентом&raquo; Полеты осуществляются на вертолетах ЕС-130Т2 компании Airbus Helicopter, группами по 4 человека.</p>\r\n\r\n<p>13:00-14:00 - Обед</p>\r\n\r\n<p>14:30-18:00 Вертолётная экскурсия &laquo;Туркестан&raquo; Экскурсия по историко-культурному заповедник-музею &laquo;Азрет-Султан&raquo;: - мавзолей Х.А.Ясави - городище Культобе - суфийский центр с подземной мечетью Хильвет - восточная баня - мавзолей Рабиги Султан Бегим</p>\r\n\r\n<p>19:00-21:00 - Ужин</p>','<p>08: 00-алым</p>\r\n\r\n<p>09: 00-10: 00 &quot;Sandyq&quot;Қазақ ұлттық мейрамханасында таңғы ас</p>\r\n\r\n<p>10: 00-12: 00 &quot;Шымкенттің үстінен&quot; тікұшақ экскурсиясы ұшулар Airbus Helicopter компаниясының ЕС-130т2 тікұшақтарында, 4 адамнан тұратын топтарда жүзеге асырылады.</p>\r\n\r\n<p>13: 00-14: 00-Түскі ас</p>\r\n\r\n<p>14: 30-18: 00 &quot;Түркістан&quot; тікұшақ экскурсиясы &quot;Әзірет Сұлтан&quot; тарихи-мәдени қорық-мұражайы бойынша Экскурсия: - Қ. а. Ясауи кесенесі-Күлтөбе қалашығы-хильвет жерасты мешіті бар сопылық орталық - шығыс моншасы-Рабиға сұлтан бегім кесенесі</p>\r\n\r\n<p>19: 00-21: 00-Кешкі ас</p>','<p>08: 00-Collection</p>\r\n\r\n<p>09: 00-10: 00 Breakfast at the national restaurant of Kazakh cuisine &quot;Sandyq&quot;</p>\r\n\r\n<p>10: 00-12: 00 Helicopter tour &quot;over Shymkent&quot; Flights are carried out on EU-130T2 helicopters of the Airbus Helicopter company, in groups of 4 people.</p>\r\n\r\n<p>13: 00-14: 00 - Lunch</p>\r\n\r\n<p>14: 30-18: 00 Helicopter tour &quot;Turkestan&quot; Excursion to the historical and cultural reserve-museum &quot;Azret-Sultan&quot;: - mausoleum of H. A.Yasavi-the settlement of Kultobe-the Sufi center with the underground mosque of Hilvet - the eastern bath-the mausoleum of Rabiga Sultan Begim</p>\r\n\r\n<p>19: 00-21: 00 - Dinner</p>','9CrX0M8BVD.png','biznes-tur',NULL,'13','150',NULL,NULL,1,'2021-08-22 01:41:17','2021-08-22 01:41:17'),(3,2,'НАУРЫЗ НАЧИНАЕТСЯ С ЮГА','НАУРЫЗ ОҢТҮСТІКТЕН БАСТАЛАДЫ','NAURYZ STARTS FROM THE SOUTH','<p><br />\r\n1 &ndash; ДЕНЬ 22 марта</p>\r\n\r\n<p>08:30-09:30 - Сбор</p>\r\n\r\n<p>10:00-14:00 Посещение ипподрома Национальные спортивные состязания</p>\r\n\r\n<p>15:00-18:00 Посещение праздничного мероприятия &laquo;Наурыз көктем &ndash; Шымқала!&raquo; на площади &laquo;Наурыз&raquo;</p>\r\n\r\n<p>18:00-21:30 - Посещение праздничного концерта</p>\r\n\r\n<p>2 &ndash; ДЕНЬ 23 марта</p>\r\n\r\n<p>08:30-09:00 - Сбор</p>\r\n\r\n<p>09:00-11:00 Гастрономический мастер-класс по приготовлению казахского завтрака в ресторане &laquo;Sandyq&raquo;</p>\r\n\r\n<p>12:00-19:00 Посещение международного фестиваля воздухоплавания &laquo;Ashyq Aspan&raquo; Официальное открытие фестиваля Дневная развлекательная программа - танцевальная программа &laquo;7 континет&raquo;, цирк, зумба, интерактив от ведущего, викторины, розыгрыши призов, флешмобы, выступления музыкантов - привязные полеты</p>\r\n\r\n<p>20:00 - Концерт от музыкальной группы</p>\r\n\r\n<p>20:30 - Парад ночного свечения</p>\r\n\r\n<p>21:30 - Open Air концерт с хедлайнером</p>\r\n\r\n<p>&nbsp;</p>','<p>1-22 наурыз күні</p>\r\n\r\n<p>08: 30-09: 30 - алым</p>\r\n\r\n<p>10: 00-14: 00 ипподромға бару ұлттық спорт жарыстары</p>\r\n\r\n<p>15: 00-18: 00 Елбасы &quot;Наурыз көктем-Шымқала!&quot;Наурыз&quot; алаңында</p>\r\n\r\n<p>18: 00-21: 30 - мерекелік концертке қатысу</p>\r\n\r\n<p>2-23 наурыз күні</p>\r\n\r\n<p>08: 30-09: 00 - алым</p>\r\n\r\n<p>09: 00-11: 00 &quot;Sandyq&quot;мейрамханасында қазақ таңғы асын дайындау бойынша гастрономиялық мастер-класс</p>\r\n\r\n<p>12: 00-19: 00 &quot;Ashyq Aspan&quot; халықаралық Әуеде жүзу фестиваліне қатысу фестивальдің ресми ашылуы күндізгі ойын-сауық бағдарламасы - &quot;7 континет&quot; би бағдарламасы, цирк, зумба, жүргізушіден интерактивті, викториналар, ұтыс ойындары, флешмобтар, музыканттардың өнер көрсетуі - байланыстағы ұшулар</p>\r\n\r\n<p>20: 00-музыкалық топтың концерті</p>\r\n\r\n<p>20: 30-Түнгі жарқыл шеруі</p>\r\n\r\n<p>21: 30-хедлайнері бар Open Air концерті</p>','<p>1-DAY of March 22</p>\r\n\r\n<p>08: 30-09: 30-Collection</p>\r\n\r\n<p>10: 00-14: 00 Visit to the racetrack National sports competitions</p>\r\n\r\n<p>15: 00-18: 00 Visit to the festive event &quot;Nauryz koktem-Shymkent!&quot; on the Nauryz Square</p>\r\n\r\n<p>18: 00-21: 30-Visit to the festive concert</p>\r\n\r\n<p>2-DAY of March 23</p>\r\n\r\n<p>08: 30-09: 00-Collection</p>\r\n\r\n<p>09: 00-11: 00 Gastronomic master class on cooking Kazakh breakfast in the &quot;Sandyq&quot;restaurant</p>\r\n\r\n<p>12: 00-19: 00 Visit to the international aeronautics festival &quot;Ashyq Aspan&quot; Official opening of the festival Daytime entertainment program-dance program &quot;7 continent&quot;, circus, zumba, interactive from the host, quizzes, prize draws, flash mobs, performances of musicians-tethered flights</p>\r\n\r\n<p>20: 00-Concert from a musical group</p>\r\n\r\n<p>20: 30-Night Glow Parade</p>\r\n\r\n<p>21: 30-Open Air concert with a headliner</p>','U4F5FnSZAh.jpg','nauryz-nachinaetsya-s-yuga',NULL,'48','150',NULL,NULL,1,'2021-08-22 01:59:49','2021-08-22 01:59:49');
/*!40000 ALTER TABLE `routes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `routes_organizators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routes_organizators` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `route_id` bigint unsigned NOT NULL,
  `organizator_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `routes_organizators_route_id_foreign` (`route_id`),
  KEY `routes_organizators_organizator_id_foreign` (`organizator_id`),
  CONSTRAINT `routes_organizators_organizator_id_foreign` FOREIGN KEY (`organizator_id`) REFERENCES `organizators` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `routes_organizators_route_id_foreign` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `routes_organizators` WRITE;
/*!40000 ALTER TABLE `routes_organizators` DISABLE KEYS */;
INSERT INTO `routes_organizators` VALUES (1,2,2,'2021-08-22 02:11:20','2021-08-22 02:11:20'),(2,3,2,'2021-08-22 02:11:47','2021-08-22 02:11:47'),(3,3,3,'2021-08-22 02:11:57','2021-08-22 02:11:57');
/*!40000 ALTER TABLE `routes_organizators` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `routes_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routes_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `route_id` bigint unsigned NOT NULL,
  `type_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `routes_types_route_id_foreign` (`route_id`),
  KEY `routes_types_type_id_foreign` (`type_id`),
  CONSTRAINT `routes_types_route_id_foreign` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `routes_types_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `route_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `routes_types` WRITE;
/*!40000 ALTER TABLE `routes_types` DISABLE KEYS */;
INSERT INTO `routes_types` VALUES (3,2,3,'2021-08-22 01:41:17','2021-08-22 01:41:17'),(4,3,3,'2021-08-22 01:59:49','2021-08-22 01:59:49');
/*!40000 ALTER TABLE `routes_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `savings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `savings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `place_id` bigint unsigned DEFAULT NULL,
  `event_id` bigint unsigned DEFAULT NULL,
  `route_id` bigint unsigned DEFAULT NULL,
  `blog_id` bigint unsigned DEFAULT NULL,
  `news_id` bigint unsigned DEFAULT NULL,
  `shop_id` bigint unsigned DEFAULT NULL,
  `organizator_id` bigint unsigned DEFAULT NULL,
  `souvenir_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `savings_user_id_foreign` (`user_id`),
  KEY `savings_place_id_foreign` (`place_id`),
  KEY `savings_event_id_foreign` (`event_id`),
  KEY `savings_route_id_foreign` (`route_id`),
  KEY `savings_blog_id_foreign` (`blog_id`),
  KEY `savings_news_id_foreign` (`news_id`),
  KEY `savings_shop_id_foreign` (`shop_id`),
  KEY `savings_organizator_id_foreign` (`organizator_id`),
  KEY `savings_souvenir_id_foreign` (`souvenir_id`),
  CONSTRAINT `savings_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `savings_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `savings_news_id_foreign` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `savings_organizator_id_foreign` FOREIGN KEY (`organizator_id`) REFERENCES `organizators` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `savings_place_id_foreign` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `savings_route_id_foreign` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `savings_shop_id_foreign` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `savings_souvenir_id_foreign` FOREIGN KEY (`souvenir_id`) REFERENCES `souvenirs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `savings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `savings` WRITE;
/*!40000 ALTER TABLE `savings` DISABLE KEYS */;
INSERT INTO `savings` VALUES (1,6,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,'2021-08-30 01:33:50','2021-08-30 01:33:50');
/*!40000 ALTER TABLE `savings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verified` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pagination` int NOT NULL DEFAULT '15',
  `order` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ASC',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'user','Пользователи/Users','3','3',15,'ASC','2021-08-21 04:09:03','2021-08-21 09:41:04'),(2,'sliders','Слайдеры/Sliders','3',NULL,15,'DESC','2021-08-21 04:09:03','2021-08-21 09:58:27'),(3,'category-place','Категория путеводителя /Category of Place','3',NULL,15,'DESC','2021-08-21 04:09:03','2021-08-22 00:15:42'),(4,'places','Путеводитель/Place','3',NULL,15,'ASC','2021-08-21 04:09:03','2021-08-21 04:34:57'),(5,'category-events','Категория событий/Category of Event','3',NULL,15,'ASC','2021-08-21 04:09:03','2021-08-21 04:31:09'),(6,'events','События/Event','3',NULL,15,'ASC','2021-08-21 04:09:03','2021-08-29 01:27:27'),(7,'route_categories',' Категория Маршрутов /Category of Route','3',NULL,15,'ASC','2021-08-21 04:09:03','2021-08-21 05:58:43'),(8,'route_types',' Тип Маршрутов /Types of Route','3',NULL,15,'ASC','2021-08-21 04:09:03','2021-08-21 05:42:45'),(9,'routes',' Маршруты /Routes','3',NULL,15,'ASC','2021-08-21 04:09:03','2021-08-21 05:57:30'),(10,'points',' Точки Маршрутов /Point Route','3',NULL,15,'ASC','2021-08-21 04:09:03','2021-08-21 06:02:10'),(11,'shops',' Магазины и ремесленики /Shops','3',NULL,15,'ASC','2021-08-21 04:09:03','2021-08-21 06:22:35'),(12,'category-souvenir','Категория Сувениров/Category of the Souvenir','3',NULL,15,'ASC','2021-08-21 04:09:03','2021-08-21 06:23:25'),(13,'souvenirs','Сувениры/Souvenirs','3',NULL,10,'ASC','2021-08-21 04:09:03','2021-08-22 02:27:43'),(14,'organizators','Гиды и турагенства/Guide and Tour Agency','3',NULL,15,'ASC','2021-08-21 04:09:03','2021-08-21 07:22:00'),(15,'category-news','Категория новостей/Category News','3',NULL,15,'ASC','2021-08-21 04:09:03','2021-08-21 07:53:32'),(16,'news','Новости/News','3',NULL,15,'ASC','2021-08-21 04:09:03','2021-08-22 05:32:35'),(17,'tags','Тэги/Tags','3',NULL,15,'ASC','2021-08-21 04:09:03','2021-08-21 08:08:09'),(18,'blogs','Блог/Blogs','3',NULL,15,'ASC','2021-08-21 04:09:03','2021-08-21 08:09:18'),(19,'reviews','Мнения/Reviews','-1',NULL,15,'ASC','2021-08-21 04:09:03','2021-08-30 01:31:11'),(20,'partners','Партнеры/Partners',NULL,NULL,15,'ASC','2021-08-21 04:09:03','2021-08-21 04:09:03');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shops` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_ru` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_kz` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eventum` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` json DEFAULT NULL,
  `social_networks` json DEFAULT NULL,
  `sites` json DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_link` longtext COLLATE utf8mb4_unicode_ci,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shops_user_id_foreign` (`user_id`),
  KEY `shops_role_id_foreign` (`role_id`),
  CONSTRAINT `shops_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `shops_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `shops` WRITE;
/*!40000 ALTER TABLE `shops` DISABLE KEYS */;
INSERT INTO `shops` VALUES (4,9,6,'Магазин Французской Культуры','Француз Мәдениеті Дүкені','French Culture Store','<h1>Интернет-магазин одежды и мебели La Redoute</h1>\r\n\r\n<p>Добро пожаловать в интернет-магазин одежды Ла Редут! Здесь вас ждут радости шопинга: модные образы, обувь, аксессуары и мебель от европейских дизайнеров.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Если вы выберете стильную одежду и обувь от нашего магазина, вам не придётся идти на поводу у переменчивой моды. В каталоге одежды La Redoute вы найдете настоящую классику французского стиля: множество вещей базового и делового гардероба, а также модную одежду и аксессуары, созданные согласно последним мировым трендам. Дизайнеры проследили, чтобы все вещи в коллекции идеально сочетались между собой. Просто составьте комплект из лаконичных вещей, добавьте любимую обувь и пару трендовых деталей. Начать разбираться в брендовой одежде вам помогут стилисты сайта, вы можете обратиться к ним через чат в любой удобный момент. Без натуральных тканей французский гардероб просто немыслим. Весенне-летняя коллекция интернет-магазина одежды La Redoute всегда содержит луки изо льна. Осенне-зимний сезон радует покупателей драгоценным кашемиром и шерстью в составе пуловеров и кардиганов.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Мебельная коллекция Ла Редут наполнена двумя брендами: премиальным AM.PM и демократичным LR Interieurs. Интерьер по-французски &ndash; это гармоничное сочетание актуальных стилей: винтаж, лофт, сканди, прованс, минимализм, с элементами экзотических культур и ретро. Какой дизайн вы бы не предпочитали, изящные линии и природные материалы мебели и декора La Redoute покорят вас с первого взгляда. Даже если вы не планируете полностью менять обстановку квартиры, вам наверняка пригодится что-то из подразделов &laquo;декор&raquo; или &laquo;текстиль&raquo;. В разделе &laquo;для гостиной&raquo; представлены диваны, журнальные столики, кресла, пуфы. Мы постоянно публикуем полезные гайды, статьи, советы по дизайну и подбору текстиля. Декораторам, архитектурным бюро мы предлагаем сотрудничество на особых условиях. Для предпринимателей, которые ищут мебель или декор для своего бизнеса, у нас предусмотрена специальная программа. Подробности ищите на соответствующих страницах сайта.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Парижский образ жизни ближе, чем вам кажется. Его можно заказать с доставкой на дом. Окружите себя красивыми предметами, наденьте новое платье, и вы увидите, как преобразится мир вокруг.</p>','<p>La Redoute интернет-киім және жиһаз дүкені</p>\r\n\r\n<p>La Redut интернет-дүкеніне қош келдіңіз! Мұнда сізді шопингтің қуанышы күтеді: еуропалық дизайнерлердің сәнді бейнелері, аяқ киімдері, аксессуарлары мен жиһаздары.</p>\r\n\r\n<p>Егер сіз біздің дүкеннен сәнді киім мен аяқ киімді таңдасаңыз, өзгермелі сәнге барудың қажеті жоқ. La Redoute киім каталогында сіз француз стилінің нағыз классикасын таба аласыз: Негізгі және іскерлік гардеробтың көптеген заттары, сонымен қатар соңғы әлемдік трендтерге сәйкес жасалған сәнді киімдер мен аксессуарлар. Дизайнерлер коллекциядағы барлық заттар бір-бірімен тамаша үйлесетініне көз жеткізді. Қысқа заттардың жиынтығын жасаңыз, сүйікті аяқ киім мен бірнеше тренд бөлшектерін қосыңыз. Сайттың стилистері сізге брендтік киімді түсінуге көмектеседі, сіз кез-келген ыңғайлы уақытта чат арқылы байланыса аласыз. Табиғи маталарсыз Француз гардеробы жай ғана мүмкін емес. La Redoute Интернет-дүкенінің көктемгі-жазғы коллекциясында әрдайым зығырдан жасалған садақтар бар. Күзгі-қысқы маусым сатып алушыларды пуловерлер мен кардигандардан тұратын қымбат кашемир мен жүнмен қуантады.</p>\r\n\r\n<p>Ла Редут жиһаз коллекциясы екі брендке толы: премиум AM.PM және демократиялық LR Interieurs. Француз интерьері-бұл қазіргі стильдердің үйлесімді үйлесімі: винтаж, лифт, сканди, прованс, минимализм, экзотикалық Мәдениеттер мен ретро элементтері бар. La Redoute жиһаздары мен декорларының талғампаз сызықтары мен табиғи материалдары сізді бір қарағанда жеңеді. Егер сіз пәтердің декорын толығымен өзгертуді жоспарламасаңыз да, &quot;декор&quot; немесе &quot;тоқыма&quot;бөлімдерінен бір нәрсе сізге пайдалы болады. &quot;Қонақ бөлмеге арналған&quot; бөлімінде дивандар, кофе үстелдері, креслолар, пуфтар бар. Біз үнемі пайдалы нұсқаулықтарды, мақалаларды, тоқыма дизайны мен таңдау бойынша кеңестерді жариялаймыз. Декораторларға, сәулет бюросына біз ерекше шарттармен ынтымақтастықты ұсынамыз. Өз бизнесі үшін жиһаз немесе декор іздейтін кәсіпкерлер үшін бізде арнайы бағдарлама бар. Толығырақ сайттың тиісті беттерінен іздеңіз.</p>\r\n\r\n<p>Париж өмір салты сіз ойлағаннан да жақын. Оны үйге жеткізумен тапсырыс беруге болады. Өзіңізді әдемі заттармен қоршап, жаңа көйлек киіңіз, сонда сіз әлемнің қалай өзгеретінін көресіз.</p>','<p>Online clothing and furniture store La Redoute</p>\r\n\r\n<p>Welcome to the online clothing store La Redoubt! Here you will find the joys of shopping: fashion images, shoes, accessories and furniture from European designers.</p>\r\n\r\n<p>If you choose stylish clothes and shoes from our store, you will not have to follow the changeable fashion. In the La Redoute clothing catalog, you will find real classics of the French style: a lot of basic and business wardrobe items, as well as fashionable clothes and accessories created according to the latest global trends. The designers made sure that all the items in the collection were perfectly combined with each other. Just make a set of concise things, add your favorite shoes and a couple of trendy details. Stylists of the site will help you to start understanding branded clothing, you can contact them via chat at any convenient time. Without natural fabrics, the French wardrobe is simply unthinkable. The spring-summer collection of the online clothing store La Redoute always contains bows made of flax. The autumn-winter season pleases customers with precious cashmere and wool as part of pullovers and cardigans.</p>\r\n\r\n<p>The La Redoubt furniture collection is filled with two brands: premium AM.PM and democratic LR Interieurs. The French interior is a harmonious combination of current styles: vintage, loft, Scandi, Provence, minimalism, with elements of exotic cultures and retro. Whatever design you would prefer, the elegant lines and natural materials of La Redoute furniture and decor will conquer you at first glance. Even if you do not plan to completely change the situation of the apartment, you will probably need something from the subsections &quot;decor&quot; or &quot;textiles&quot;. In the section &quot;for the living room&quot; there are sofas, coffee tables, armchairs, poufs. We constantly publish useful guides, articles, tips on design and selection of textiles. We offer cooperation to decorators and architectural bureaus on special conditions. For entrepreneurs who are looking for furniture or decor for their business, we have a special program. For more information, look at the corresponding pages of the site.</p>\r\n\r\n<p>The Parisian way of life is closer than you think. It can be ordered with home delivery. Surround yourself with beautiful objects, put on a new dress, and you will see how the world around you will be transformed.</p>','magazin-francuzskoy-kultury','f2w3KttMrj.jpg',NULL,NULL,NULL,NULL,'ул Байдибек Би 22',NULL,1,'2021-08-22 02:15:44','2021-08-22 02:15:44'),(5,10,7,'Джессика Витч','Джессика Витч','Jessica Witch','<p><br />\r\nПерсональная информация</p>\r\n\r\n<p>Художник-живописец, ремесленник, победитель областных конкурсов, участник республиканских симпозиумов.</p>\r\n\r\n<p>Родился в 1993 году в поселке Старый Икан Туркестанской области. После средне-специального образования в школе поступил в Шымкентский художественный колледж им.А. Кастеева по специальности &laquo;станковая живопись&raquo;.</p>\r\n\r\n<p>В 2013 году обучался в Южно-Казахстанском педагогическом университете по специальности &laquo;Изобразительное искусство и черчение&raquo;.</p>\r\n\r\n<p>В 2016 году приняли участие в областном конкурсе &ndash; выставке художников &laquo;Казыгурт-береке, бірлік бастауы&raquo;, в 2017 году-фестивале&raquo; &laquo;Шабыт&raquo;, в конкурсе-выставке &laquo;Бір өлең-бір сурет&raquo;, в 2018 и 2019 годах-областном пленэре республиканского фестиваля тюльпанов &laquo;АҚСУ-ЖАБАГЫЛЫ АЛАУЫ, ШУБАЙ Қызыл ЖАЛАУЫ&raquo;.</p>\r\n\r\n<p>В 2018 году в рамках празднования 20-летия столицы-города Астаны обладатель международной премии имени Физули Курал Көркем &quot;Қазақ елі&quot;,&quot;Астанаға нұр шашу&quot; завоевал Гран &ndash; При на конкурсе молодых художников &laquo;Бір өлең-бір сурет&raquo;.</p>\r\n\r\n<p>С 2019 года магистр искусствоведческих наук. В настоящее время занимается не только научной работой, но и творчеством.</p>\r\n\r\n<p>&nbsp;</p>','<p>Жеке ақпарат</p>\r\n\r\n<p>Суретші-кескіндемеші, қолөнерші, облыстық байқаулардың жеңімпазы, республикалық симпозиумдардың қатысушысы.</p>\r\n\r\n<p>1993 жылы Түркістан облысының Ескі Иқан ауылында дүниеге келген. Орта арнаулы білім алғаннан кейін мектепте Шымкент көркемсурет колледжіне оқуға түсті.Ә.Қастеевтің &quot;станоктық кескіндеме&quot;мамандығы бойынша.</p>\r\n\r\n<p>2013 жылы Оңтүстік Қазақстан педагогикалық университетінде &quot;бейнелеу өнері және сызу&quot;мамандығы бойынша оқыды.</p>\r\n\r\n<p>2016 жылы &quot;Қазығұрт &ndash; береке, бірлік бастауы&quot; облыстық суретшілер көрме-конкурсына, 2017 жылы&quot; Шабыт &quot;фестиваліне,&quot; Бір өлең-бір сурет &quot;көрме-конкурсына, 2018 және 2019 жылдары&quot; АҚСУ-Жабағылы АЛАУЫ, Шұбай Қызыл ЖАЛАУЫ &quot;республикалық Қызғалдақ фестивалінің облыстық пленэріне қатысты.</p>\r\n\r\n<p>2018 жылы Астана қаласының 20 жылдығын мерекелеу аясында Физули құрал Көркем атындағы &quot;Қазақ елі&quot;халықаралық сыйлығының иегері,&quot;Астанаға нұр шашу&quot; жас суретшілердің &quot;Бір өлең-бір сурет&quot;байқауында бас жүлдені жеңіп алды.</p>\r\n\r\n<p>2019 жылдан өнертану ғылымдарының магистрі. Қазіргі уақытта ол тек ғылыми жұмыстармен ғана емес, шығармашылықпен де айналысады.</p>','<p>Personal information</p>\r\n\r\n<p>Artist-painter, craftsman, winner of regional competitions, participant of republican symposiums.</p>\r\n\r\n<p>He was born in 1993 in the village of Stary Ikan, Turkestan region. After secondary special education at school, he entered the Shymkent Art College named after A. Kasteev, majoring in &quot;easel painting&quot;.</p>\r\n\r\n<p>In 2013, he studied at the South Kazakhstan Pedagogical University, majoring in Fine Arts and Drawing.</p>\r\n\r\n<p>In 2016, they took part in the regional competition &ndash; exhibition of artists &quot;Kazygurt-bereke, birlik bastauy&quot;, in 2017-the festival&quot; Shabyt&quot;, in the competition-exhibition&quot; Bir olen-bir suret&quot;, in 2018 and 2019-the regional plein air of the republican tulip festival&quot; AKSU-ZHABAGYLY ALAUY, SHUBAI Kyzyl ZHALAUY&quot;.</p>\r\n\r\n<p>In 2018, as part of the celebration of the 20th anniversary of the capital-the city of Astana, the winner of the international prize named after Fizuli Kural Korkem &quot;Kazakh eli&quot;,&quot;Astana nur shashu&quot; won the Grand Prix at the competition of young artists &quot;Bir olen-bir suret&quot;.</p>\r\n\r\n<p>Since 2019, Master of Arts in Art History. Currently, he is engaged not only in scientific work, but also in creative work.</p>','dzhessika-vitch','6VvRW2qHJV.jpg',NULL,'[\"+7 776 677 69 93\"]','[\"sanya_93_93.20@mail.ru\", \"art_gallerey@mail.ru\"]',NULL,'г. Шымкент, ул. Бейбитшилик 22, кв. 30','[{\"lat\":42.322914911901705,\"lng\":69.59083557128908}]',1,'2021-08-22 02:20:50','2021-08-22 02:20:50');
/*!40000 ALTER TABLE `shops` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sliders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sliders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_ru` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_kz` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `button_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `button_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `button_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` int NOT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sliders` WRITE;
/*!40000 ALTER TABLE `sliders` DISABLE KEYS */;
INSERT INTO `sliders` VALUES (1,'Шымкентский центр Туризма','Shymkent Tourism Center','Shymkent Tourism Center','Шымкенсткий центр туризма - готовы прийти на помощь!','Шымкент туризм орталығы-көмекке келуге дайын!','Shymkent Tourism Center-we are ready to help!','Подробнее','Толығырақ','More info','https://visit-shymkent.kz/visitplace/238','a0qLuQCXiE.jpg',1,1,'2021-08-21 09:53:32','2021-08-21 09:53:33'),(2,'Аэропорт города Шымкент','Шымкент қаласының әуежайы','Shymkent City Airport','Комфортные перелеты, хороший сервис','Ыңғайлы ұшулар, жақсы сервис','Comfortable flights, good service','Бронировать','Брондау','Book','https://visit-shymkent.kz/Events/64','O7H7sOwWUk.jpg',2,1,'2021-08-21 09:57:52','2021-08-21 09:57:52'),(3,'Шыментский зоопарк открылся!','Шымкент хайуанаттар бағы ашылды!','The Shymkent zoo has opened!','Купите и забронируйте билеты уже сегодня!','Билеттерді бүгін сатып алыңыз және брондаңыз!','Buy and book your tickets today!','Купить','Сатып алу','Buy tickets','https://visit-shymkent.kz/Events/1','kZtIE9IvrV.jpg',3,1,'2021-08-21 10:01:00','2021-08-21 10:01:09');
/*!40000 ALTER TABLE `sliders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `socials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `socials` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `socials` WRITE;
/*!40000 ALTER TABLE `socials` DISABLE KEYS */;
/*!40000 ALTER TABLE `socials` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `souvenir_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `souvenir_category` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `souvenir_category` WRITE;
/*!40000 ALTER TABLE `souvenir_category` DISABLE KEYS */;
INSERT INTO `souvenir_category` VALUES (2,'Казахские национальные сувениры','Қазақтың ұлттық сувенирлері','Kazakh national souvenirs','kazahskie-nacionalnye-suveniry',NULL,1,'2021-08-22 02:22:32','2021-08-22 02:22:32');
/*!40000 ALTER TABLE `souvenir_category` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `souvenirs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `souvenirs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned DEFAULT NULL,
  `shop_id` bigint unsigned NOT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_ru` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_kz` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `eventum` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `souvenirs_category_id_foreign` (`category_id`),
  KEY `souvenirs_shop_id_foreign` (`shop_id`),
  CONSTRAINT `souvenirs_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `souvenir_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `souvenirs_shop_id_foreign` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `souvenirs` WRITE;
/*!40000 ALTER TABLE `souvenirs` DISABLE KEYS */;
INSERT INTO `souvenirs` VALUES (4,NULL,4,'Роман Виктора Гюго - Отверженные','Роман Виктора Гюго - Отверженные','Victor Hugo\'s novel Les Miserables','roman-viktora-gyugo-otverzhennye','<p>Роман-эпопея Виктора Гюго &laquo;Отверженные&raquo; (1862)&nbsp;&mdash; огромный текст, без которого невозможно представить себе духовную историю XIX века. В&nbsp;сущности, это &laquo;война и&nbsp;мир&raquo; великого французского классика, только здесь находит отражение не&nbsp;противостояние вражеских армий, но&nbsp;война, которую ведут между собой добро и&nbsp;зло в&nbsp;человеческой душе и&nbsp;в&nbsp;обществе. При создании &laquo;Отверженных&raquo; автора, по&nbsp;его словам, прежде всего волновали три темы: &laquo;угнетение мужчины&hellip; падение женщины по&nbsp;причине голода, увядание ребенка вследствие мрака невежества&raquo;, что отразилось в&nbsp;историях главных действующих лиц: каторжника Жана Вальжана, Фантины и&nbsp;Козетты. Фантастически закрученная авантюрная фабула заставляет следить с&nbsp;неотрывным вниманием за&nbsp;событиями, которые разворачиваются на&nbsp;улицах старого Парижа, в&nbsp;трущобах и&nbsp;на&nbsp;баррикадах. Не&nbsp;случайно в&nbsp;XX&nbsp;веке насчитывается десятки экранизаций &laquo;Отверженных&raquo;&nbsp;&mdash; от&nbsp;немой ленты &laquo;На&nbsp;баррикадах&raquo; (1907) до&nbsp;последнего фильма Тома Хупера.<br />\r\n<br />\r\nСокращенный перевод с французского под редакцией Э. О. Выгодской.</p>','<p>Виктор Гюгоның &quot;Les Miserables&quot; роман-эпосы (1862) &mdash; үлкен мәтін, онсыз XIX ғасырдың рухани тарихын елестету мүмкін емес. Шын мәнінде, бұл Ұлы француз классигінің&quot; соғыс және бейбітшілік&quot;, мұнда тек жау әскерлерінің қарама-қайшылығы емес, адам жаны мен қоғамдағы жақсылық пен жамандық арасындағы соғыс көрінеді. &quot;Қабылданбаған&quot; авторды құру кезінде, оның айтуынша, ең алдымен, үш тақырып мазалаған: &quot;ер адамның езгісі... аштық салдарынан әйелдің құлауы, надандықтың қараңғысына байланысты баланың қурап қалуы&quot;, бұл басты кейіпкерлердің әңгімелерінде көрініс тапты: сотталушы Жан Вальжан, Фантина және Козетта. Фантастикалық бұралған авантюралық сюжет сізді ескі Париж көшелерінде, қараңғы жерлерде және баррикадаларда болып жатқан оқиғаларға ерекше назар аударуға мәжбүр етеді. ХХ ғасырда &quot;қабылданбаған&quot; ондаған бейімделулер &mdash; &quot;баррикадалардағы&quot; үнсіз таспадан (1907) том Хупердің соңғы фильміне дейін болуы кездейсоқ емес.</p>\r\n\r\n<p>Э. о. Выгодской өңдеген француз тілінен қысқартылған аударма.</p>','<p>Victor Hugo&#39;s epic novel Les Miserables (1862) is a huge text, without which it is impossible to imagine the spiritual history of the XIX century. In essence, this is the &quot;war and peace&quot; of the great French classic, only here is reflected not the confrontation of enemy armies, but the war that is waged between good and evil in the human soul and in society. When creating &quot;Les Miserables&quot;, the author, according to him, was primarily concerned with three themes: &quot;the oppression of a man... the fall of a woman due to hunger, the withering of a child due to the darkness of ignorance&quot;, which was reflected in the stories of the main characters: the convict Jean Valjean, Fantine and Cosette. A fantastically twisted adventurous plot makes you follow with undivided attention the events that unfold on the streets of old Paris, in the slums and on the barricades. It is no coincidence that in the XX century there are dozens of film adaptations of Les Miserables-from the silent film &quot;On the Barricades&quot; (1907) to the last film by Tom Hooper.</p>\r\n\r\n<p>Abridged translation from the French, edited by E. O. Vygodskaya.</p>',NULL,'p1v3ufv7Ej.png','1500',1,'2021-08-22 02:27:32','2021-08-22 02:27:32'),(5,NULL,5,'Картина Крадущийся Тигр','Сурет Жасырылған Жолбарыс','Painting The Hiding Tiger','kartina-kradushchiysya-tigr','<p>Джессика добилась настоящего успеха в жанре анимализма которое доступно только по-настоящему талантливому мастеру живописи.</p>\r\n\r\n<p>Художница работает с 2013 года, в основном, пишет картины с изображением лошадей, много времени тратит на изучение анатомии и материала которым пишет.<br />\r\nКартина станет настоящим украшением любого интерьера.</p>','<p>Джессика нағыз талантты кескіндеме шебері үшін қол жетімді анимализм жанрында нақты жетістікке жетті.</p>\r\n\r\n<p>Суретші 2013 жылдан бері жұмыс істейді, Негізінен жылқылардың суреттерін салады, анатомия мен материалды зерттеуге көп уақыт жұмсайды.<br />\r\nСурет кез-келген интерьердің нағыз әшекейі болады.</p>','<p>Jessica has achieved real success in the genre of animalism, which is available only to a truly talented master of painting.</p>\r\n\r\n<p>The artist has been working since 2013, mainly paints paintings depicting horses, spends a lot of time studying anatomy and the material with which she writes.<br />\r\nThe picture will become a real decoration of any interior.</p>','112215121','nlyqhydyGb.jpg','15000',1,'2021-08-22 02:31:37','2021-08-22 02:31:37'),(6,2,5,'Казахские национальные одеяния для детей','Балаларға арналған Қазақтың ұлттық киімдері','Kazakh national dresses for children','kazahskie-nacionalnye-odeyaniya-dlya-detey','<p>Мы предлагаем Вам огромный выбор проката костюмов и сценической одежды на любую тематику&ndash; народные и национальные костюмы, наряды в восточном стиле и для жгучего испанского фламенко, школьная форма и даже одежда в стиле &ldquo;Стиляги&rdquo;.</p>\r\n\r\n<p>Наши услуги по прокату костюмов помогут вам отлично провести время и создать хорошее настроение себе, друзьям и коллегам! Хотите уникальный костюм, единственный в своем роде? Компания &ldquo;Орион&rdquo; обладает прекрасным ателье, где профессиональные мастера создадут сценический костюм исходя из Ваших пожеланий.</p>\r\n\r\n<p>Приемлемые цены на прокат и продажу костюмов &ndash; еще одна приятная опция.</p>','<p>Біз сізге кез&ndash; келген тақырыптағы костюмдер мен сахналық киімдерді жалға алудың үлкен таңдауын ұсынамыз-халықтық және ұлттық костюмдер, шығыс стиліндегі киімдер және испандық фламенко, мектеп формасы, тіпті &quot;Стиляги&quot;стиліндегі киімдер.</p>\r\n\r\n<p>Біздің костюмдерді жалға беру қызметтеріміз сізге жақсы уақыт өткізуге және өзіңізге, достарыңызға және әріптестеріңізге жақсы көңіл-күй қалыптастыруға көмектеседі! Сізге бірегей костюм керек пе? &quot;Орион&quot; компаниясының керемет ательесі бар, онда кәсіби шеберлер сіздің қалауыңызға қарай сахналық костюм жасайды.</p>\r\n\r\n<p>Костюмдерді жалға алу мен сатудың қолайлы бағасы-тағы бір жағымды нұсқа.</p>','<p>We offer you a huge selection of rental costumes and stage clothes on any subject&ndash; folk and national costumes, dresses in oriental style and for burning Spanish flamenco, school uniforms and even clothes in the style of &quot;Dudes&quot;.</p>\r\n\r\n<p>Our costume rental services will help you have a great time and create a good mood for yourself, friends and colleagues! Do you want a unique costume, one of a kind? The Orion company has an excellent atelier, where professional craftsmen will create a stage costume based on your wishes.</p>\r\n\r\n<p>Reasonable prices for the rental and sale of costumes are another pleasant option.</p>',NULL,'X2Kp7YOdXo.jpg','10000',1,'2021-08-22 02:35:48','2021-08-22 02:35:48');
/*!40000 ALTER TABLE `souvenirs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (2,'Мнения','Opinion','Пікірлер','mneniya',NULL,1,'2021-08-22 02:50:01','2021-08-22 02:50:01'),(3,'Места','Places','Орындар','mesta',NULL,1,'2021-08-22 02:50:29','2021-08-22 02:50:29'),(4,'Кухня','Kitchen','Асхана','kuhnya',NULL,1,'2021-08-27 23:53:31','2021-08-27 23:53:31');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` int NOT NULL DEFAULT '1',
  `verified` int NOT NULL DEFAULT '0',
  `remember_token` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_phone_unique` (`phone`),
  KEY `users_role_id_foreign` (`role_id`),
  CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'Администратор','admin@gmail.com','+7777777777','$2y$10$Qau/T4C1JshA3inFLrcESOr90VW93ORLse.pAfRqyMwfmXvK2DfDu','DuROemHORw.jpg',NULL,1,1,'JnRjG9I9cPbtRajlPFMwQb7eck1Y2iPn9q4ThZQ5gqyJiXC3w83YXuMoAFnG','2021-08-21 04:09:03','2021-08-21 09:39:32'),(5,1,'Модератор Visit Shymkent','moderator@gmail.com','+7778878787','$2y$10$yFkyoP6GRg3zpmxWx0O92ePhzWAY8Ze5CGuzad.8G20mwwzok1.j6','iMnmTQX3bN.jpg',NULL,1,1,NULL,'2021-08-21 09:40:13','2021-08-28 00:24:10'),(6,3,'Lara Croft','lara@gmail.com','+770269026215584','$2y$10$pLbZDPXr1zUEv8L5xW1ovu0jyaz.hoKUILQdlVpHGt39NCddwUXZi','YLCqV5O1Tt.jpg',NULL,1,1,NULL,'2021-08-21 09:40:50','2021-08-21 09:40:50'),(7,4,'Indiana Jones','guide@gmail.com','+7778777877','$2y$10$Cm9EiSkQ4Y.KHWJu8adXvubmY7EkuGd6K4mkCobit6NOIuD.a3PPm','12hIuzGIym.jpg',NULL,1,1,NULL,'2021-08-21 09:43:05','2021-08-21 09:43:05'),(8,5,'ТОО Турагенство','tour-agency@gmail.com','+7787877887878','$2y$10$r5V2BZtiGzQzDfphgXo1GOM8GUHOtwxDgtJYnUPffvPmCzvpooIEW','GYlfa3gWVD.jpg',NULL,1,1,NULL,'2021-08-21 09:44:59','2021-08-21 09:44:59'),(9,6,'De la porte de France','shop@gmail.com','+787887878','$2y$10$kQgcIzx99vv95EFvsDcFeeyoKm49z6hzhxzm8pSCUH/FJM0aVlCZa','TU0tXG5eLw.jpg',NULL,1,1,NULL,'2021-08-21 09:46:15','2021-08-21 09:46:15'),(10,7,'Jessica Witch','craftman@gmail.com','+788787','$2y$10$XR66MkhPwkARbZMhRFcP9O2u2beRLpUha6LOd3aQ4ZlZKA9D8fSVa','jd28YL8mqd.jpg',NULL,1,1,NULL,'2021-08-21 09:47:07','2021-08-21 09:47:07'),(11,8,'TEST','test@gmail.com','8877878','$2y$10$9w3T/B8mhNHNJX4JW3W1J.kwu1on1AlKn18vW9YMg4vXsd3JVJo0q','cm99aCGOCw.jpg',NULL,0,1,NULL,'2021-08-22 09:35:02','2021-08-22 09:53:56'),(12,4,'Гид Визит Шымкент','guide2@gmail.com','3123123123','$2y$10$gHhrXNr/ZVIQRjpL7k4AC.HJ0CjuTLMSSDJLIOKKym/vqQBQRuaI2','QrBR8IuI2H.jpg','Guide 2',1,1,NULL,'2021-08-29 07:50:46','2021-08-29 07:50:46');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `weekdays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `weekdays` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_kz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `weekdays` WRITE;
/*!40000 ALTER TABLE `weekdays` DISABLE KEYS */;
INSERT INTO `weekdays` VALUES (1,'Ежедневно','Күн сайын','Everyday','2021-08-21 04:09:03','2021-08-21 04:09:03'),(2,'Определенное время','Белгілі бір уақытта','Specified time','2021-08-21 04:09:03','2021-08-21 04:09:03'),(3,'Понедельник','Дүйсенбі','Monday','2021-08-21 04:09:03','2021-08-21 04:09:03'),(4,'Вторник','Сейсенбі','Tuesday','2021-08-21 04:09:03','2021-08-21 04:09:03'),(5,'Среда','Сәрсенбі','Wednesday','2021-08-21 04:09:03','2021-08-21 04:09:03'),(6,'Четверг','Бейсенбі','Thursday','2021-08-21 04:09:03','2021-08-21 04:09:03'),(7,'Пятница','Жұма','Friday','2021-08-21 04:09:03','2021-08-21 04:09:03'),(8,'Суббота','Сенбі','Saturday','2021-08-21 04:09:03','2021-08-21 04:09:03'),(9,'Воскресенье','Жексенбі','Sunday','2021-08-21 04:09:03','2021-08-21 04:09:03');
/*!40000 ALTER TABLE `weekdays` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `workdays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workdays` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `place_id` bigint unsigned DEFAULT NULL,
  `event_id` bigint unsigned DEFAULT NULL,
  `shop_id` bigint unsigned DEFAULT NULL,
  `weekday_id` bigint unsigned NOT NULL,
  `date_start` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_end` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_start` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_end` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `workdays_place_id_foreign` (`place_id`),
  KEY `workdays_event_id_foreign` (`event_id`),
  KEY `workdays_shop_id_foreign` (`shop_id`),
  KEY `workdays_weekday_id_foreign` (`weekday_id`),
  CONSTRAINT `workdays_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `workdays_place_id_foreign` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `workdays_shop_id_foreign` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `workdays_weekday_id_foreign` FOREIGN KEY (`weekday_id`) REFERENCES `weekdays` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `workdays` WRITE;
/*!40000 ALTER TABLE `workdays` DISABLE KEYS */;
INSERT INTO `workdays` VALUES (1,6,NULL,NULL,1,NULL,NULL,'09:00','22:00','2021-08-22 00:54:07','2021-08-22 00:54:07'),(2,NULL,5,NULL,1,NULL,NULL,NULL,NULL,'2021-08-22 01:18:27','2021-08-22 01:18:27'),(3,9,NULL,NULL,1,NULL,NULL,'11:00','23:00','2021-08-22 01:31:37','2021-08-22 01:31:37'),(4,NULL,6,NULL,1,'29/08/2021','31/08/2021','10:00','12:00','2021-08-28 23:59:57','2021-08-28 23:59:57'),(5,NULL,7,NULL,2,'30/08/2021','31/08/2021','09:00','18:00','2021-08-29 00:44:17','2021-08-29 00:44:17'),(6,NULL,8,NULL,2,'30/08/2021','01/09/2021',NULL,NULL,'2021-08-29 00:54:17','2021-08-29 00:54:17'),(7,NULL,NULL,4,1,NULL,NULL,'09:00','18:00','2021-08-30 00:19:08','2021-08-30 00:19:08');
/*!40000 ALTER TABLE `workdays` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

